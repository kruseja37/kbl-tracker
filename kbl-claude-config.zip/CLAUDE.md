# KBL Tracker - Project Instructions

> **For Claude Code CLI. Core operating principles are in `.claude/rules/` (auto-loaded).**

---

## Quick Start

**New session?** Run `/kbl-start` to load context from spec-docs.

**End of session?** Run `/kbl-end` to save state to spec-docs.

---

## Available Commands

| Command | Purpose |
|---------|---------|
| `/kbl-start` | Initialize session with proper context loading |
| `/kbl-nfl` | Run 3-tier Negative Feedback Loop verification |
| `/kbl-checkpoint` | Save state at milestone (pre-compaction) |
| `/kbl-end` | Close session with all docs updated |
| `/kbl-audit` | Run spec-to-implementation audit |

---

## Key Spec Documents

### Session Management
- `spec-docs/CURRENT_STATE.md` - What's implemented (READ FIRST)
- `spec-docs/SESSION_LOG.md` - Recent work history
- `spec-docs/DECISIONS_LOG.md` - Why decisions were made

### Implementation Reference
- `spec-docs/IMPLEMENTATION_PLAN_v2.md` - Active sprint plan
- `spec-docs/FEATURE_WISHLIST.md` - Known gaps (124 items)

### WAR Calculations
- `spec-docs/BWAR_CALCULATION_SPEC.md` - Batting WAR
- `spec-docs/PWAR_CALCULATION_SPEC.md` - Pitching WAR
- `spec-docs/FWAR_CALCULATION_SPEC.md` - Fielding WAR
- `spec-docs/RWAR_CALCULATION_SPEC.md` - Baserunning WAR
- `spec-docs/MWAR_CALCULATION_SPEC.md` - Manager WAR

### Game Systems
- `spec-docs/SMB4_GAME_MECHANICS.md` - What IS/ISN'T in SMB4
- `spec-docs/SPECIAL_EVENTS_SPEC.md` - Fame events
- `spec-docs/MOJO_FITNESS_SYSTEM_SPEC.md` - Mojo/Fitness
- `spec-docs/SALARY_SYSTEM_SPEC.md` - Salary calculation

---

## Project Structure

```
kbl-tracker/
├── src/
│   ├── components/GameTracker/  # UI components
│   ├── engines/                 # Calculation engines (WAR, Salary, etc.)
│   ├── storage/                 # IndexedDB persistence
│   ├── hooks/                   # React hooks
│   └── types/                   # TypeScript types
├── spec-docs/                   # Living documentation (SOURCE OF TRUTH)
├── tests/                       # Test files
└── .claude/
    ├── rules/                   # Auto-loaded operating principles
    └── commands/                # Slash commands
```

---

## SMB4 Context

**This is a VIDEO GAME tracker for Super Mega Baseball 4.**

NOT real baseball. No balks, no catcher interference, no umpire calls.

See `spec-docs/SMB4_GAME_MECHANICS.md` for full reference.

---

## Browser Testing

Use Playwright MCP for UI verification:
```
"Use playwright mcp to open a browser to http://localhost:5173/"
```

---

## Build Verification

```bash
npm run build    # Must exit 0
npm test         # 267+ tests must pass
```

**Never declare complete without passing build.**
