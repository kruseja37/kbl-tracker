# KBL Tracker - Claude Code Configuration v2

**Tailored configuration for KBL Tracker based on your existing operating principles and the "everything-claude-code" patterns.**

---

## What's Included

### Rules (Auto-loaded every session)

| File | Purpose |
|------|---------|
| `kbl-operating-principles.md` | 3-tier NFL, scope discipline, completion protocol |
| `kbl-gotchas.md` | Known issues, SMB4 context, established patterns |
| `kbl-detection-philosophy.md` | Non-user-intensive design, detection tiers |

### Commands (Slash commands)

| Command | Purpose |
|---------|---------|
| `/kbl-start` | Initialize session with context loading |
| `/kbl-nfl` | Run 3-tier NFL verification |
| `/kbl-checkpoint` | Save state at milestones |
| `/kbl-end` | Close session with docs updated |
| `/kbl-audit` | Spec-to-implementation audit |

### Updated CLAUDE.md

Slimmed down version that references the rules files instead of duplicating content.

---

## Installation

### Step 1: Install "everything-claude-code" Plugin (Optional but Recommended)

This gives you the base memory persistence hooks:

```bash
# In Claude Code CLI:
/plugin marketplace add affaan-m/everything-claude-code
/plugin install everything-claude-code@everything-claude-code
```

### Step 2: Copy KBL-Specific Files

```bash
# Navigate to your KBL Tracker project
cd ~/Projects/kbl-tracker

# Create the .claude directory structure
mkdir -p .claude/rules
mkdir -p .claude/commands

# Copy rules (from downloaded files)
cp kbl-operating-principles.md .claude/rules/
cp kbl-gotchas.md .claude/rules/
cp kbl-detection-philosophy.md .claude/rules/

# Copy commands
cp kbl-start.md .claude/commands/
cp kbl-nfl.md .claude/commands/
cp kbl-checkpoint.md .claude/commands/
cp kbl-end.md .claude/commands/
cp kbl-audit.md .claude/commands/

# Replace CLAUDE.md (backup old one first)
cp CLAUDE.md CLAUDE.md.backup
cp CLAUDE-new.md CLAUDE.md
```

### Step 3: Restart Claude Code

```bash
cd ~/Projects/kbl-tracker
claude
```

The rules files will auto-load. Commands will be available as `/kbl-*`.

---

## What Changed from Your Original Setup

| Before | After | Why |
|--------|-------|-----|
| `AI_OPERATING_PREFERENCES.md` in spec-docs (read manually) | Core principles in `.claude/rules/` (auto-loaded) | No more "forgetting" to read operating principles |
| Long `CLAUDE.md` with everything | Slim `CLAUDE.md` referencing rules | Separation of concerns, easier to maintain |
| No slash commands | 5 KBL-specific commands | Standardized workflows |
| Manual session handoff | `/kbl-start`, `/kbl-end` commands | Consistent context loading/saving |
| NFL process described but not enforced | `/kbl-nfl` command with structured output | Reproducible verification |

---

## Your Existing Files (Keep These)

**DO NOT DELETE these - they're still your source of truth:**

- `spec-docs/CURRENT_STATE.md`
- `spec-docs/SESSION_LOG.md`
- `spec-docs/DECISIONS_LOG.md`
- `spec-docs/AI_OPERATING_PREFERENCES.md` (keep as detailed reference)
- All `*_SPEC.md` files

The new rules complement these files, they don't replace them.

---

## Daily Workflow

### Starting Work

```bash
cd ~/Projects/kbl-tracker
claude --continue   # Resume last session
# OR
claude              # New session
```

Then run:
```
/kbl-start
```

### During Work

After implementing anything:
```
/kbl-nfl
```

At milestones or before compaction:
```
/kbl-checkpoint
```

### Ending Work

```
/kbl-end
```

---

## Comparison: Before vs After

### Before (Manual Process)
1. Start session
2. Remember to read CURRENT_STATE.md
3. Remember to read AI_OPERATING_PREFERENCES.md
4. Remember NFL has 3 tiers
5. Remember to update SESSION_LOG
6. Hope nothing was forgotten

### After (Automated + Commands)
1. Start session → Rules auto-loaded
2. Run `/kbl-start` → Context loaded, summarized
3. Work → Rules guide behavior
4. Run `/kbl-nfl` → Structured 3-tier verification
5. Run `/kbl-end` → All docs updated systematically

---

## Troubleshooting

### Commands not appearing
- Ensure files are in `.claude/commands/` (note the dot)
- Restart Claude Code
- Check file permissions

### Rules not being followed
- Rules are guidance, not hard enforcement
- Explicitly reference the rule if needed
- Add critical items to the rule files

### Context still getting lost
- Use `/kbl-checkpoint` more frequently
- Always run `/kbl-end` before closing
- Use `claude --continue` to resume sessions

---

## File Structure After Installation

```
kbl-tracker/
├── .claude/
│   ├── rules/
│   │   ├── kbl-operating-principles.md
│   │   ├── kbl-gotchas.md
│   │   └── kbl-detection-philosophy.md
│   └── commands/
│       ├── kbl-start.md
│       ├── kbl-nfl.md
│       ├── kbl-checkpoint.md
│       ├── kbl-end.md
│       └── kbl-audit.md
├── spec-docs/                    # Your existing docs (unchanged)
│   ├── CURRENT_STATE.md
│   ├── SESSION_LOG.md
│   ├── DECISIONS_LOG.md
│   ├── AI_OPERATING_PREFERENCES.md
│   └── [all other specs]
├── src/                          # Your code
├── CLAUDE.md                     # Updated (slimmer)
└── .mcp.json                     # Your existing Playwright config
```
