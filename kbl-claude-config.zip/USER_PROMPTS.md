# KBL Tracker - Prompt Templates for User

> **Copy-paste these prompts to get thorough, non-hallucinated responses.**

---

## Prompt 1: Implementation Request

Use when asking Claude to implement something:

```
Implement [FEATURE].

REQUIREMENTS:
1. Before coding, read the relevant spec file(s) and list what you find
2. After coding, fill out the FULL Implementation Verification template from kbl-verification-templates.md
3. Paste ACTUAL terminal output, not descriptions
4. Fill EVERY field in the data flow trace with real file:line references
5. If you cannot verify externally, provide specific test steps for me

Do not say "complete" until the template is fully filled with real data.
```

---

## Prompt 2: Comprehensive Spec Audit

Use when you want a REAL audit, not a quick scan:

```
Audit [SPEC FILE or "all WAR specs" or "all specs"].

REQUIREMENTS:
1. Read the ENTIRE spec file, not just headers
2. For EACH requirement in the spec, search the codebase for implementation
3. Fill out the Spec Audit template for EACH spec file
4. Show actual grep/search results, not summaries
5. For every constant/formula, show BOTH spec value AND code value with file:line
6. Do not skip sections - if a section has no issues, explicitly say "Section X: 0 issues found"
7. At the end, provide a count: X requirements checked, Y matching, Z gaps

Do not summarize. Do not skip. Fill every field.
```

---

## Prompt 3: Browser Testing

Use when you want REAL UI testing:

```
Test [FEATURE] in the browser.

REQUIREMENTS:
1. Navigate to [URL or localhost:5173]
2. Take a screenshot BEFORE starting
3. For EACH action, record in the Browser Test template:
   - What you clicked/typed
   - What you expected
   - What actually happened
   - Screenshot after the action
4. Check IndexedDB (Application tab > IndexedDB) and report what you see
5. Check Console for errors and paste any you find
6. Take a screenshot AFTER completing all steps
7. Fill the FULL Browser Test template with actual data

If something fails, STOP and tell me exactly what failed with a screenshot.
```

---

## Prompt 4: Breaking the Fix Loop

Use when Claude has "fixed" something multiple times but it's still broken:

```
STOP trying to fix this.

Run /kbl-stuck and:
1. Document EXACTLY what is broken (not vague - specific behavior)
2. List EVERY fix you've already attempted and what happened
3. Tell me the specific test steps I should perform
4. DO NOT attempt another fix until I report back what I observe

I will test and tell you what I see. Then we can proceed with real data.
```

---

## Prompt 5: Verification Challenge

Use when Claude claims something is "working" or "complete":

```
You said this is working. Prove it.

Fill out the Implementation Verification template with:
1. Actual npm build output (paste it)
2. Actual npm test output (paste it)
3. Complete file:line trace for data flow
4. Grep results showing the function is actually called somewhere

If you cannot provide all of these, change your status to "UNVERIFIED" and tell me what test steps I should perform.
```

---

## Prompt 6: Force Full File Reading

Use when you suspect Claude is skimming:

```
Read [FILE] completely.

After reading, prove you read it by:
1. Telling me the total line count
2. Listing the main sections/headers
3. Quoting one specific detail from the MIDDLE of the file (not first or last 10%)
4. Quoting one specific detail from near the END of the file

Then proceed with [TASK].
```

---

## Prompt 7: Anti-Hallucination Check

Use periodically to verify Claude is being accurate:

```
I want to verify your accuracy. For your last response:

1. Pick 3 specific claims you made
2. For each claim, show me the EXACT evidence:
   - If it's about code: paste the actual code and file:line
   - If it's about a spec: quote the spec and line number
   - If it's about behavior: describe how to reproduce

If you cannot provide evidence for a claim, retract it.
```

---

## Prompt 8: Session Start (Thorough)

Use at the start of every session:

```
Starting a new session.

1. Read spec-docs/CURRENT_STATE.md fully and summarize:
   - Build status
   - What's implemented
   - What's blocked
   - Known bugs

2. Read spec-docs/SESSION_LOG.md (top 2-3 entries) and summarize:
   - What was done last session
   - What was left pending

3. Read spec-docs/DECISIONS_LOG.md (recent entries) and note any relevant decisions

4. After reading, confirm: "Based on docs, we are at [X]. Last session accomplished [Y]. Pending: [Z]. Is this correct?"

Wait for my confirmation before proceeding.
```

---

## Quick Reference: When to Use What

| Situation | Prompt to Use |
|-----------|---------------|
| Asking for implementation | Prompt 1 |
| Want to check spec alignment | Prompt 2 |
| Need UI testing | Prompt 3 |
| Stuck in fix loop | Prompt 4 |
| Claude says "done" but you're skeptical | Prompt 5 |
| Suspect Claude is skimming | Prompt 6 |
| Want to spot-check accuracy | Prompt 7 |
| Starting a session | Prompt 8 |
