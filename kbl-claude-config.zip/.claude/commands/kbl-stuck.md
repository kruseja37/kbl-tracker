# /kbl-stuck - Break the Infinite Fix Loop

**Use when:** You've tried to fix something multiple times and it's still broken.

---

## Purpose

This command forces Claude to STOP trying to fix and instead:
1. Document exactly what's broken
2. Document what was already tried
3. Request external verification
4. Wait for user feedback before proceeding

---

## Execution Steps

### 1. STOP Attempting Fixes

**Do not write any more code until this process completes.**

### 2. Document the Failure State

Write to `spec-docs/CURRENT_STATE.md` under a new section:

```markdown
## ⚠️ STUCK: [Feature Name] - [Date]

### Symptom
[Exact description of what's not working - be SPECIFIC]
- Expected behavior: [what should happen]
- Actual behavior: [what actually happens]
- Error messages: [if any, paste exactly]

### Location
- Primary file: [path/to/file.ts]
- Line numbers: [specific lines involved]
- Related files: [list]

### Attempts Made
| # | What I Tried | Result |
|---|--------------|--------|
| 1 | [description] | [what happened] |
| 2 | [description] | [what happened] |
| 3 | [description] | [what happened] |

### Hypotheses Remaining
- [ ] [Possible cause 1]
- [ ] [Possible cause 2]

### External Verification Needed
User should test:
1. [Step 1]
2. [Step 2]
3. [Step 3]

Report back:
- Does [X] appear on screen?
- What shows in browser console? (F12 → Console tab)
- Does data appear in IndexedDB? (F12 → Application → IndexedDB)
```

### 3. Present to User

```
## I'm Stuck on [Feature]

I've attempted [N] fixes but the issue persists. Before trying again, I need external verification.

### What's Not Working
[Brief description]

### What I've Tried
1. [Attempt 1]
2. [Attempt 2]
3. [Attempt 3]

### I Need You To Test

Please run the app and check:
1. [Specific test step]
2. [Specific test step]
3. Open browser DevTools (F12) and check:
   - Console tab: Any errors?
   - Application → IndexedDB: Is [store name] populated?

### Next Steps
- If you see [X], the issue is [Y]
- If you see [Z], the issue is [W]

**I will wait for your feedback before attempting another fix.**
```

### 4. WAIT

**Do not attempt any fixes until user responds with test results.**

When user responds:
- If they confirm the issue, use their feedback to make ONE targeted fix
- If they say it works, verify what changed and update docs
- If unclear, ask clarifying questions

---

## When to Use This Command

Trigger conditions:
- You've "fixed" the same thing 3+ times
- User says "it's still not working" after your fix
- You're making changes but can't verify them externally
- You feel like you're going in circles

---

## Why This Works

1. **Breaks the loop** - Forces a pause instead of endless retries
2. **Externalizes verification** - User tests in real environment
3. **Documents attempts** - Prevents re-trying failed approaches
4. **Gathers real data** - User feedback is ground truth
5. **Prevents hallucination** - Can't claim "fixed" without user confirmation
