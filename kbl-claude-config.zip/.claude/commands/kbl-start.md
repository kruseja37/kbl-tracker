# /kbl-start - Session Start Protocol

Initialize a KBL Tracker work session with proper context loading.

---

## Execution Steps

### 1. Read Core State Files

Read these files IN ORDER:

```
spec-docs/CURRENT_STATE.md
spec-docs/SESSION_LOG.md (from top - newest first)
spec-docs/DECISIONS_LOG.md
```

### 2. Summarize Current State

Extract and present:
- **Build Status**: Passing/Failing
- **Implementation Plan Status**: Which day, what's complete
- **Last Session**: What was accomplished
- **Blocked Items**: Any blockers noted
- **Known Bugs**: Any open issues

### 3. Check for Relevant Specs

If user has mentioned what they want to work on, identify relevant spec files:
- WAR calculations → `*WAR_CALCULATION_SPEC.md`
- Fielding → `FIELDING_SYSTEM_SPEC.md`
- Fame/Events → `SPECIAL_EVENTS_SPEC.md`, `FAME_SYSTEM_TRACKING.md`
- Mojo/Fitness → `MOJO_FITNESS_SYSTEM_SPEC.md`
- Salary → `SALARY_SYSTEM_SPEC.md`

### 4. Present Context Summary

```
## KBL Tracker Session Initialized

### Build Status
✅ PASSING (as of [date])

### Current Implementation State
- Day [X] of Implementation Plan v3
- Last completed: [summary]
- Next planned: [summary]

### From Last Session ([date])
**Accomplished:**
- [item 1]
- [item 2]

**Left Pending:**
- [item 1]
- [item 2]

### Blockers
- [list or "None"]

### Relevant Specs for Today
- [list based on user intent, or "Awaiting task direction"]

---

**Is this context correct? What would you like to work on?**
```

### 5. Wait for Confirmation

**DO NOT proceed with any work until user confirms context is correct.**

---

## If Discrepancies Found

If SESSION_LOG and CURRENT_STATE have conflicts:
1. Note the discrepancy
2. Ask user which is correct
3. Update the incorrect file after confirmation
