# /kbl-checkpoint - Save Session State

Create a checkpoint of current session state at a logical milestone.

---

## When to Use
- After completing a feature or significant milestone
- Before starting a potentially risky change
- When context is getting long (pre-compaction)
- At natural transition points in work
- When user requests a save point

---

## Execution Steps

### 1. Gather Accomplishments

Ask user (or summarize from session):
- What has been accomplished this session?
- Any decisions made?
- Any issues discovered?

### 2. Update CURRENT_STATE.md

Make these changes:
- Update "Last Updated" date and context
- Move completed items to ✅ Completed section
- Update 🚧 In Progress section
- Add any new bugs to Known Bugs table
- Update Build Status if changed

### 3. Append to SESSION_LOG.md

Add checkpoint entry at TOP of file:

```markdown
## Checkpoint: [Date] - [Time]

### Accomplished So Far
- [completed item 1]
- [completed item 2]

### Current State
- Working on: [current task]
- Blocked by: [if any]

### Decisions Made
- [decision 1]: [brief rationale]

### Files Modified
- `path/to/file.ts` - [what changed]

### Notes for Continuation
- [critical context that shouldn't be lost]

---
```

### 4. Update DECISIONS_LOG.md (if applicable)

If any architectural or design decisions were made, add entry:

```markdown
### [Date]: [Decision Title]

**Context**: [What led to this decision]
**Decision**: [What was decided]
**Rationale**: [Why]
**Implications**: [What this affects]
```

### 5. Update kbl-gotchas.md (if applicable)

If any new patterns or anti-patterns were discovered:
- Add to appropriate section
- Include what/why/how-to-fix

### 6. Confirm Checkpoint

```
## Checkpoint Saved

### Files Updated
- ✅ CURRENT_STATE.md (status, last updated)
- ✅ SESSION_LOG.md (checkpoint entry)
- [✅ DECISIONS_LOG.md if applicable]
- [✅ kbl-gotchas.md if applicable]

### Summary
- Completed: [count] items
- In Progress: [current work]
- Blockers: [yes/no]

### Context Preserved
All important state has been saved to spec-docs.
Safe to continue, compact, or end session.
```

---

## Pre-Compaction Usage

If context window is getting full:

```
Context is getting long. Running checkpoint before compaction.

[Execute checkpoint steps above]

Checkpoint complete. You may now run /compact.
After compaction, run /kbl-start to reload context from spec-docs.
```
