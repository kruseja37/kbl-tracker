# /kbl-end - Session Close Protocol

Properly close a KBL Tracker session with all documentation updated.

---

## When to Use
- End of work session
- Before extended break
- When user says "let's wrap up" or similar

---

## Execution Steps

### 1. Run End-of-Day NFL (if implementation day)

If this was an implementation day, run `/kbl-nfl` first:
- All 3 tiers must be checked
- If any tier fails, mark day as PARTIAL not COMPLETE

### 2. Gather Session Summary

Confirm with user:
- What was accomplished?
- What was left incomplete?
- Any blockers or open questions?
- Any decisions made?

### 3. Update CURRENT_STATE.md

**Required updates:**
- "Last Updated" date with session context
- Move completed items to appropriate sections
- Update Implementation Plan status (Day X complete/partial)
- Add any new bugs discovered
- Update Build Status

### 4. Create SESSION_LOG.md Entry

Add at TOP of file:

```markdown
## Session: [Date] - [Brief Description]

### What Was Accomplished
- ✅ [completed task 1]
- ✅ [completed task 2]
- 🚧 [partial task - what's done, what's left]

### Decisions Made
- [Decision]: [Brief rationale]

### NFL Results (if implementation day)
- Tier 1 (Code): ✅/❌
- Tier 2 (Data Flow): ✅/❌
- Tier 3 (Spec Alignment): ✅/❌
- **Day Status**: COMPLETE / PARTIAL

### Bugs Found/Fixed
- [Bug]: [Status]

### Pending / Next Steps
- [ ] [Next task 1]
- [ ] [Next task 2]
- Blocked by: [if any]

### Key Context for Next Session
- [Critical info that shouldn't be lost]
- [Where to pick up]
- [Any gotchas discovered]

### Files Modified
- `path/to/file.ts` - [what changed]

---
```

### 5. Update DECISIONS_LOG.md (if applicable)

For any architectural/design decisions made this session.

### 6. Update kbl-gotchas.md (if applicable)

For any new:
- Anti-patterns discovered
- Patterns established
- Error/solution pairs

### 7. Final Confirmation

```
## Session Ended: [Date]

### Documentation Updated
- ✅ CURRENT_STATE.md
- ✅ SESSION_LOG.md
- [✅ DECISIONS_LOG.md if applicable]
- [✅ kbl-gotchas.md if applicable]

### Session Summary
| Metric | Value |
|--------|-------|
| Tasks Completed | [count] |
| Tasks Partial | [count] |
| Bugs Fixed | [count] |
| Decisions Made | [count] |
| NFL Status | COMPLETE / PARTIAL / NOT RUN |

### Next Session Start Point
[Brief description of where to pick up]

### Commands for Next Session
```bash
cd ~/Projects/kbl-tracker
claude --continue  # Resume this session
# OR
claude             # New session, then run /kbl-start
```

---

Ready to close. All context preserved in spec-docs.
```

---

## Critical Reminders

1. **Never skip SESSION_LOG update** - This is how context survives
2. **Be specific about "what's left"** - Vague notes lose context
3. **Include file:line references** for in-progress work
4. **If NFL failed, clearly state PARTIAL** - Don't claim COMPLETE
