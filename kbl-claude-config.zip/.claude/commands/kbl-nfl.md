# /kbl-nfl - Execute Three-Tier NFL Verification

Run the complete Negative Feedback Loop verification for KBL Tracker.

---

## When to Use
- After implementing any feature or fix
- At end of implementation day (MANDATORY)
- When user requests verification

---

## Execution Steps

### Tier 1: Code-Level NFL

1. **Build Verification**
   ```bash
   npm run build
   ```
   - MUST exit 0
   - If fails, STOP and fix before proceeding

2. **Run Test Suites**
   ```bash
   npm test
   ```
   - All 267+ tests must pass
   - Note any failures

3. **Edge Case Testing**
   Actively try to break the feature:
   - Null/undefined inputs
   - Empty arrays/objects
   - Boundary values (0, -1, max)
   - Invalid state combinations

4. **Document Tier 1 Results**
   ```
   TIER 1 RESULTS:
   - Build: ✅/❌
   - Tests: X/Y passing
   - Edge cases tested: [list]
   - Issues found: [list or "None"]
   ```

### Tier 2: Data Flow NFL

**For the feature being verified, trace the COMPLETE pipeline:**

1. **UI Input** → Does UI exist to collect this data?
   - File: ___
   - Line: ___
   - Component: ___

2. **Storage** → Does data persist to IndexedDB?
   - Write call file: ___
   - Line: ___
   - Store name: ___

3. **Calculator** → Is calculator called with real data?
   - Import in: ___
   - Called at line: ___
   - With data from: ___

4. **Display** → Is result shown to user?
   - Component: ___
   - Renders at: ___

**Document Tier 2 Results:**
```
TIER 2 RESULTS:
- UI collects data: ✅/❌ (file:line)
- Data persists: ✅/❌ (file:line)
- Calculator called: ✅/❌ (file:line)
- Result displayed: ✅/❌ (file:line)

If ANY ❌: Feature has ORPHANED components - FIX BEFORE PROCEEDING
```

### Tier 3: Spec Alignment Audit

1. **Identify relevant spec files** for the feature
2. **Compare spec requirements vs implementation:**
   - Constants match?
   - Formulas match?
   - Enum/type values match?
   - All spec features implemented?

3. **Document Tier 3 Results:**
   ```
   TIER 3 RESULTS:
   - Spec file(s) checked: [list]
   - Mismatches found: [list or "None"]
   - Missing features: [list or "None"]
   ```

---

## Final Report Template

```
## NFL VERIFICATION COMPLETE

### Feature: [Name]
### Date: [Date]

### Tier 1: Code-Level
- Build: ✅ Exit 0
- Tests: 267/267 passing
- Edge cases: [tested X, Y, Z]
- Issues: None

### Tier 2: Data Flow
- UI → Storage → Calculator → Display: ✅ VERIFIED
- Evidence:
  - UI: [file:line]
  - Storage: [file:line]
  - Calculator: [file:line]
  - Display: [file:line]

### Tier 3: Spec Alignment
- Specs checked: [list]
- Mismatches: None
- Missing: None

### VERDICT: ✅ ALL TIERS PASSED
(or)
### VERDICT: ❌ TIER X FAILED - [reason]

### Status: COMPLETE / PARTIAL
```

---

## If Any Tier Fails

1. **Document the failure** clearly
2. **Do NOT mark as complete** - status is "PARTIAL"
3. **Create action items** for fixing
4. **Update CURRENT_STATE.md** with partial status
5. **Ask user** how to proceed
