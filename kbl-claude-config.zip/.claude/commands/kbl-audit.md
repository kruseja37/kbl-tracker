# /kbl-audit - Spec-to-Implementation Audit (NO SHORTCUTS)

**This is a THOROUGH audit. Do not skim. Do not summarize. Check EVERYTHING.**

---

## Anti-Shortcut Rules

1. **Read the ENTIRE spec file** - Not just headers, not just first/last sections
2. **Check EVERY requirement** - Not "most requirements" or "key requirements"  
3. **Show your work** - Paste grep results, show file:line references
4. **No summarizing findings** - List each finding individually
5. **Fill the template completely** - Every field, every row

**If this feels tedious, you're doing it right.**

---

## Execution Steps

### 1. Identify Scope

Ask user or determine from context:
- **Full audit**: All spec files (takes longer)
- **Targeted audit**: Specific system (WAR, Fame, Mojo, etc.)
- **Feature audit**: Single feature being implemented

### 2. For Each Spec File in Scope

**Read the FULL spec file**, then for EACH requirement:

```
1. Quote the requirement from the spec (with line number)
2. Search codebase: grep -r "[relevant term]" src/
3. Paste the grep results (actual output)
4. If found: provide file:line and quote the relevant code
5. If not found: mark as GAP
6. If different: mark as MISMATCH and show both values
```

**Do not batch or summarize. Process one requirement at a time.**

### 3. Document Gaps

For each finding, use this format:

```
FEATURE: [name]
SPEC FILE: [filename.md]
SPEC SAYS: [requirement/value]
IMPLEMENTATION: [what exists] or "MISSING" or "DIFFERENT: [actual]"
PRIORITY: HIGH/MEDIUM/LOW
STATUS: GAP / ORPHANED / MISMATCH
```

**Priority Guidelines:**
- **HIGH**: Core functionality broken or missing
- **MEDIUM**: Feature incomplete but workaround exists
- **LOW**: Nice-to-have, cosmetic, or edge case

**Status Types:**
- **GAP**: Spec'd but not implemented
- **ORPHANED**: Implemented but not connected (Tier 2 failure)
- **MISMATCH**: Different values/logic between spec and code

### 4. Check Integration Points

For each major feature, verify:
- [ ] Does UI call the engine?
- [ ] Does engine read from storage?
- [ ] Does result display in UI?
- [ ] Is data persisted?

### 5. Compile Audit Report

```markdown
## KBL Tracker Audit Report

**Date**: [Date]
**Scope**: [Full / System: X / Feature: Y]
**Auditor**: Claude

### Summary

| Priority | Count |
|----------|-------|
| HIGH | [X] |
| MEDIUM | [Y] |
| LOW | [Z] |
| **TOTAL** | [sum] |

### Critical Issues (HIGH Priority)

| Feature | Spec File | Issue | Status |
|---------|-----------|-------|--------|
| [name] | [file] | [description] | GAP/ORPHANED/MISMATCH |

### Major Issues (MEDIUM Priority)

[table format]

### Minor Issues (LOW Priority)

[table format or summary]

### Orphaned Code Check

| Component | File | Connected? | Issue |
|-----------|------|------------|-------|
| [calculator] | [file.ts] | ✅/❌ | [if ❌, what's missing] |

### Recommendations

1. [Action item 1]
2. [Action item 2]

### Files Checked

- [x] SPEC_FILE_1.md
- [x] SPEC_FILE_2.md
- [ ] SPEC_FILE_3.md (out of scope)
```

### 6. Update Tracking

If gaps found:
1. Add HIGH priority items to FEATURE_WISHLIST.md or CURRENT_STATE.md
2. Update relevant spec files if documentation is wrong
3. Create action items for next session

---

## Quick Audit Checklist

For a fast targeted audit:

```
□ Read the spec file for [feature]
□ Find implementation file(s) in src/
□ Check: Constants match?
□ Check: Formulas match?
□ Check: Enum values match?
□ Check: UI collects required data?
□ Check: Data persists to storage?
□ Check: Calculator is called?
□ Check: Result is displayed?
□ Document any gaps
```

---

## Post-Audit Protocol

**CRITICAL**: After documenting fixes in audit report:

1. **Verify changes in actual spec files** (not just audit report)
2. Run grep to confirm old values are gone:
   ```bash
   grep -n "old_value" spec-docs/*.md  # Should return nothing
   ```
3. Items only in audit report (not in specs) must be applied or re-opened
