# KBL Tracker - Core Operating Principles

> **Auto-loaded by Claude Code. These rules are MANDATORY.**
>
> **See also: `kbl-anti-hallucination.md` for proof requirements.**

---

## CRITICAL: The Hallucination Problem

Claude tends to claim "working" without external verification. This creates infinite fix loops.

**MANDATORY RULE: Never claim success without PROOF.**

Acceptable proof:
- Actual terminal output from `npm run build` / `npm test`
- Browser screenshot showing feature working
- Complete file:line trace showing data flow
- User confirmation after testing

**If you cannot provide proof, say "UNVERIFIED" not "complete".**

---

## Session Start Protocol

**BEFORE doing any work, READ these files IN ORDER:**
1. `spec-docs/CURRENT_STATE.md` - What's implemented and what's not
2. `spec-docs/SESSION_LOG.md` - Recent context (read from top, newest first)
3. `spec-docs/DECISIONS_LOG.md` - Key design decisions

**Confirm understanding before proceeding:**
> "Based on docs, we're at [X point]. Last session accomplished [Y]. Is this correct?"

**DO NOT rely on compaction summaries - they lose nuance. Read the actual files.**

---

## The Three-Tier NFL (Negative Feedback Loop)

**Core Principle: Assume failure until proven otherwise.**

### Tier 1: Code-Level NFL (After every implementation)
1. **Actively try to disprove success** - Attempt to break what was just created
2. **Test edge cases** - Boundary conditions, unusual inputs, failure modes
3. **Verify assumptions** - Question every assumption made
4. **Document findings** - Record what was tested and passed/failed
5. **Iterate until unfalsifiable** - Only stop when you cannot disprove correctness

### Tier 2: Data Flow NFL (After every feature)
Verify the complete pipeline works end-to-end:

```
UI (Input) → Storage (Persist) → Calculator (Process) → Display (Output)
```

**MANDATORY: Provide FILE:LINE evidence for each step:**

```
□ UI INPUT:     [file.tsx]:[line] - Component that collects data
□ STORAGE:      [file.ts]:[line] - Function that writes to IndexedDB  
□ CALLED FROM:  [file.tsx]:[line] - Where storage function is invoked
□ CALCULATOR:   [file.ts]:[line] - Engine that processes data
□ CALLED FROM:  [file.tsx]:[line] - Where calculator is invoked
□ DISPLAY:      [file.tsx]:[line] - Component that shows result
□ RENDERS IN:   [file.tsx]:[line] - Where display component is used
```

**If ANY box cannot be filled with a specific file:line, the feature is INCOMPLETE.**

**WARNING**: A calculator that exists but is never called is an ORPHAN. A data type collected but not persisted is LOST. Both are bugs Tier 1 won't catch.

**Orphan detection:**
```bash
grep -r "functionName" src/
# If only found in its own file, it's ORPHANED
```

### Tier 3: Spec-to-Implementation Audit (End of day/phase)
Compare EVERY spec document against actual implementation:
- **Missing features** - Spec'd but not implemented
- **Partial features** - Started but incomplete
- **Orphaned code** - Implemented but not connected
- **Spec/code mismatches** - Different values, logic, or behavior

---

## End-of-Day Checkpoint (MANDATORY)

```
┌────────────────────────────────────────────────────────────────┐
│  END-OF-DAY NFL CHECKPOINT                                     │
├────────────────────────────────────────────────────────────────┤
│  □ Tier 1: Try to BREAK the code (edge cases, null inputs)     │
│  □ Tier 2: Verify FULL pipeline: UI → Storage → Calc → Display │
│  □ Tier 3: Compare implementation against SPEC requirements    │
├────────────────────────────────────────────────────────────────┤
│  Only after ALL THREE pass can you mark day as complete.       │
│  If ANY tier fails, day status = PARTIAL, document gaps.       │
└────────────────────────────────────────────────────────────────┘
```

---

## Scope Discipline

- **Default to thoroughness** - Complete tasks to full scope as requested
- **Never silently reduce scope** - Communicate effort required BEFORE adjusting
- **Ask before changing objectives** - Always confirm before modifying task parameters

---

## Completion Protocol

**Before declaring ANY task complete:**

1. **Provide build output** - Paste actual `npm run build` result
2. **Provide test output** - Paste actual `npm test` result  
3. **Provide file:line trace** - Complete Tier 2 checklist with specific locations
4. **Provide external verification** - Screenshot, user test, or explicit "cannot verify"
5. State any remaining uncertainties
6. If any tier failed, explicitly state "PARTIAL" or "UNVERIFIED"
7. Ask user to confirm

**NEVER say "complete" or "working" without items 1-4.**

**If you cannot verify externally, say:**
> "Implementation complete but UNVERIFIED. User should test: [specific steps]"

---

## Write-First Principle

**If it's important, write it to a file before moving on.**
- Treat chat as ephemeral, docs as permanent
- Don't say "I'll remember" - write it down
- Spec files are the source of truth, not session logs

---

## Spec File Authority

| Document Type | Purpose | Trust Level |
|---------------|---------|-------------|
| *_SPEC.md files | Source of truth | HIGH - This is what matters |
| CURRENT_STATE.md | Implementation status | HIGH - Current reality |
| DECISIONS_LOG.md | Why decisions were made | HIGH - Context |
| SESSION_LOG.md | Historical record | MEDIUM - Context only |
| Audit reports | Track what was done | MEDIUM - Verify against specs |

**The spec file is the only thing that matters. If the spec file doesn't have the fix, it's not fixed.**
