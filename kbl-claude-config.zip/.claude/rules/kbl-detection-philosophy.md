# KBL Tracker - GameTracker Design Philosophy

> **Auto-loaded by Claude Code. Follow these principles when implementing detection logic.**

---

## Core Philosophy: Non-User-Intensive Design

**The GameTracker should be as non-user-intensive as possible by leveraging inferential logic based on real baseball gameplay intuition.**

The user watches and plays the game - they shouldn't be constantly interrupted to record obvious events. The system should:

1. **Infer what it can** from existing play-by-play data
2. **Prompt only when uncertain** (and make prompts easy to dismiss or confirm)
3. **Never ask the obvious** - if baseball logic dictates the outcome, don't ask

---

## Detection Tiers

| Tier | User Effort | When to Use | Examples |
|------|-------------|-------------|----------|
| **Auto-Detect** | None | Determinable from data | Cycle, no-hitter, blown save, milestones |
| **Prompt-Detect** | 1 click (Y/N) | System suspects, needs confirmation | Web gem, TOOTBLAN, robbery |
| **Manual Entry** | Multiple clicks | Cannot infer, user initiates | Nut shot, killed pitcher |

---

## Implementation Guidelines

### 1. Baseball Intuition First
What would a knowledgeable fan expect?
- 4+ pitches thrown at runner = likely nut shot? Prompt.
- Fly out in deep zone with diving catch animation → likely web gem? Prompt.
- Pitcher faces minimum batters through 5 → detect no-hitter progress automatically.

### 2. Confidence Thresholds
- **High confidence (>90%)** → Auto-detect, no prompt
- **Medium confidence (50-90%)** → Prompt with suggestion
- **Low confidence (<50%)** → Don't prompt, leave to manual entry

### 3. Minimal Disruption
- Prompts should be dismissible with one tap
- Group related prompts (don't ask 3 questions in a row)
- Remember user preferences for prompt frequency

---

## Detection Functions Reference

**~45 detection functions documented in `DETECTION_FUNCTIONS_IMPLEMENTATION.md`**

### Auto-Detect Events
- Cycle detection
- No-hitter / Perfect game progress
- Blown save
- Statistical milestones (career HR, season hits, etc.)
- Immaculate inning
- Maddux (CG shutout < 100 pitches)

### Prompt-Detect Events
- Web Gem (fly out in deep zone + high difficulty)
- Robbery (HR denied at wall)
- TOOTBLAN (runner out on bases in stupid way)
- Nut Shot (pitcher hit by comebacker)
- Triple Play (3 outs on one play)

### Manual Entry Events (Quick Buttons Available)
- 🥜 Nut Shot
- 💥 Killed Pitcher
- 🤦 TOOTBLAN
- ⭐ Web Gem

---

## Fame System Integration

Detection events feed into the Fame system:

| Event | Fame Impact | Notes |
|-------|-------------|-------|
| Web Gem | +2 Fame | Fielder |
| Robbery | +1 Fame | Fielder |
| TOOTBLAN | -3 Fame | Runner |
| Nut Shot (survives) | +2 Fame | Pitcher |
| Nut Shot (exits) | +1 Fame | Pitcher |
| Failed HR Robbery | -1 Fame | Fielder |

**Fame Value Calculation:**
```
fameValue = baseFame × √LI × playoffMultiplier
```

Where LI is Leverage Index (LI=4 → 2× multiplier, LI=9 → 3× multiplier)

---

## Related Spec Documents

- `spec-docs/DETECTION_FUNCTIONS_IMPLEMENTATION.md` - All detection functions
- `spec-docs/SPECIAL_EVENTS_SPEC.md` - Fame Bonus/Boner events
- `spec-docs/FAME_SYSTEM_TRACKING.md` - Fame implementation status
- `spec-docs/FIELDING_SYSTEM_SPEC.md` - Fielding inference logic
