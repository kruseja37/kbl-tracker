# KBL Tracker - Mandatory Verification Templates

> **These templates MUST be filled with ACTUAL DATA. Blanks = INCOMPLETE.**

---

## Template 1: Implementation Verification

**USE AFTER: Any code implementation**

Copy this template and fill EVERY field with actual values:

```
## IMPLEMENTATION VERIFICATION

### Feature: _______________
### Date: _______________

### BUILD PROOF
Command run: `npm run build`
Exit code: ___
Timestamp: ___

Paste ACTUAL terminal output (first and last 5 lines minimum):
```
[PASTE HERE - NOT A DESCRIPTION, THE ACTUAL OUTPUT]
```

### TEST PROOF  
Command run: `npm test`
Total tests: ___
Passing: ___
Failing: ___

Paste ACTUAL terminal output showing test results:
```
[PASTE HERE - NOT A DESCRIPTION, THE ACTUAL OUTPUT]
```

### DATA FLOW TRACE
Fill EVERY line with actual file paths and line numbers:

| Step | File | Line | Function/Component |
|------|------|------|-------------------|
| UI collects data | ___.tsx | ___ | ___() |
| Calls storage | ___.tsx | ___ | ___() |
| Storage writes | ___.ts | ___ | ___() |
| Calculator imported in | ___.tsx | ___ | import { ___ } |
| Calculator called at | ___.tsx | ___ | ___() |
| Display component | ___.tsx | ___ | <___> |
| Rendered in | ___.tsx | ___ | <___> |

### ORPHAN CHECK
Command run: `grep -r "[main function name]" src/`
Results (paste actual output):
```
[PASTE HERE]
```
Found in ___ files. If only 1-2 files (definition + test), explain where it's used: ___

### EXTERNAL VERIFICATION
☐ Browser screenshot taken? (Yes/No): ___
☐ If No, why not: ___
☐ User test steps provided? (Yes/No): ___

### VERDICT
☐ All fields filled with actual data: ___
☐ Any "___" remaining: ___ (if yes, status = INCOMPLETE)

STATUS: [ VERIFIED | UNVERIFIED | INCOMPLETE ]
```

---

## Template 2: Spec Audit

**USE FOR: Comprehensive spec-to-code comparison**

```
## SPEC AUDIT: [Spec File Name]

### Spec File: spec-docs/_______________.md
### Date: _______________
### Auditor: Claude

### SPEC READING PROOF
File size: ___ lines
Key sections identified:
1. ___
2. ___
3. ___

### CONSTANTS COMPARISON

| Constant | Spec Value | Spec Location | Code Value | Code Location | Match? |
|----------|------------|---------------|------------|---------------|--------|
| ___ | ___ | line ___ | ___ | file:line | ✅/❌ |
| ___ | ___ | line ___ | ___ | file:line | ✅/❌ |
| ___ | ___ | line ___ | ___ | file:line | ✅/❌ |

### FORMULA COMPARISON

| Formula | Spec Says | Code Does | Match? |
|---------|-----------|-----------|--------|
| ___ | ___ | ___ (file:line) | ✅/❌ |

### FEATURE CHECKLIST

| Spec Requirement | Implemented? | Evidence (file:line) |
|------------------|--------------|---------------------|
| ___ | Yes/No/Partial | ___ |
| ___ | Yes/No/Partial | ___ |

### INTEGRATION CHECK
☐ UI exists to trigger this feature: ___ (file:line)
☐ Data persists to storage: ___ (file:line)
☐ Calculator is called (not orphaned): ___ (file:line)
☐ Result is displayed: ___ (file:line)

### GAPS FOUND

| Gap | Severity | Spec Location | Notes |
|-----|----------|---------------|-------|
| ___ | HIGH/MED/LOW | line ___ | ___ |

### SUMMARY
- Total requirements checked: ___
- Matching: ___
- Mismatched: ___
- Missing: ___
- Orphaned: ___

STATUS: [ CLEAN | GAPS FOUND | INCOMPLETE AUDIT ]
```

---

## Template 3: Browser Test

**USE FOR: UI/integration testing**

```
## BROWSER TEST REPORT

### Feature: _______________
### URL: _______________
### Date: _______________

### PRE-TEST STATE
Screenshot taken: Yes/No
Screenshot ID: ___
Page loaded successfully: Yes/No

### TEST STEPS EXECUTED

| # | Action | Element | Expected | Actual | Pass? |
|---|--------|---------|----------|--------|-------|
| 1 | ___ | ___ | ___ | ___ | ✅/❌ |
| 2 | ___ | ___ | ___ | ___ | ✅/❌ |
| 3 | ___ | ___ | ___ | ___ | ✅/❌ |

### DATA PERSISTENCE CHECK
☐ Action performed that should save data: ___
☐ Page refreshed: Yes/No
☐ Data still present after refresh: Yes/No
☐ IndexedDB checked (Application > IndexedDB): Yes/No
☐ Relevant store: ___
☐ Records found: ___

### CONSOLE ERRORS
☐ DevTools Console opened: Yes/No
☐ Errors found: Yes/No
☐ If yes, paste errors:
```
[PASTE ACTUAL CONSOLE ERRORS]
```

### POST-TEST SCREENSHOT
Screenshot taken: Yes/No
Screenshot ID: ___

### VERDICT
- Steps passed: ___ / ___
- Data persists: Yes/No
- Console errors: Yes/No

STATUS: [ PASS | FAIL | PARTIAL | BLOCKED ]

If FAIL, specific failure:
___
```

---

## How to Use These Templates

### For Implementation
After ANY code change, say:
> "Fill out the Implementation Verification template with actual data."

### For Audits  
Before starting an audit, say:
> "For each spec file, fill out the Spec Audit template. Do not summarize - fill every field."

### For Browser Testing
Before UI testing, say:
> "Use the Browser Test template. Fill every field. Take screenshots at each step."

---

## Red Flags in Filled Templates

**These indicate incomplete/hallucinated responses:**

- Any field still shows "___"
- "See above" or "as mentioned" instead of actual values
- Descriptions instead of actual terminal output
- "Should be" or "would be" instead of actual observed values
- Missing screenshots when browser testing was possible
- Grep results not shown (just "found in X files")
