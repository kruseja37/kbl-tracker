# KBL Tracker - Known Gotchas & Established Patterns

> **Auto-loaded by Claude Code. Learn from past mistakes.**

**Last Updated:** 2026-01-25

---

## CRITICAL: SMB4 Context

**This is a VIDEO GAME tracker for Super Mega Baseball 4, NOT real baseball.**

The following do NOT exist in SMB4:
- ❌ Balks (removed from UI Jan 25, 2026)
- ❌ Catcher interference
- ❌ Batter/runner interference
- ❌ Umpire judgment calls
- ❌ Checked swing rulings
- ❌ Pitch clock violations

**Reference**: `spec-docs/SMB4_GAME_MECHANICS.md` for what IS/ISN'T in the game.

---

## NEVER DO THESE

### Build/Type Safety
- **NEVER skip `npm run build`** - Exit 0 required before declaring anything complete
- **NEVER ignore TypeScript errors** - All 267+ tests must pass
- **NEVER use `any` type** without explicit justification in comments
- **NEVER use `@ts-ignore`** without documenting why

### Data Flow Anti-Patterns
- **NEVER create "orphaned" code** - Every calculator must be CALLED from somewhere
- **NEVER assume data persists** - Verify IndexedDB writes actually happen
- **NEVER skip Tier 2 NFL** - Most commonly skipped, catches orphaned code

### Spec Discipline
- **NEVER update audit reports without updating spec files** - Spec is source of truth
- **NEVER trust compaction summaries** - Read actual spec-docs
- **NEVER mark issues "resolved" without verifying spec file changes**

### Session Management
- **NEVER declare "COMPLETE" if any NFL tier failed** - Use "PARTIAL"
- **NEVER end session without updating SESSION_LOG.md**
- **NEVER rely on chat memory** - Write important context to files

---

## ALWAYS DO THESE

### Before Any Implementation
1. Read relevant SPEC files for the feature
2. Check CURRENT_STATE.md for what already exists
3. Propose approach and get user confirmation

### After Any Implementation
1. Run `npm run build` - must exit 0
2. Run relevant test suites
3. Run Tier 1 NFL (try to break it)
4. Run Tier 2 NFL (verify data flows end-to-end)
5. Update CURRENT_STATE.md if feature status changed

### End of Day
1. Run all 3 NFL tiers
2. Update SESSION_LOG.md with accomplishments
3. Update CURRENT_STATE.md with any changes
4. Note any new gotchas in this file

---

## Established Patterns

### SMB4 Baselines (from ADAPTIVE_STANDARDS_ENGINE_SPEC.md)
```typescript
// WAR Calculation Constants
const LEAGUE_WOBA = 0.329;
const WOBA_SCALE = 1.7821;
const LEAGUE_FIP = 4.04;
const FIP_CONSTANT = 3.28;

// Replacement Level
const BATTER_REPLACEMENT = -12.0; // runs per 600 PA
const STARTER_REPLACEMENT = 0.12;
const RELIEVER_REPLACEMENT = 0.03;

// Runs Per Win (CRITICAL - scales with season length)
const RUNS_PER_WIN = 10 * (seasonGames / 162);
// Example: 50 games = 3.09 RPW, NOT the 17.87 from run environment
```

### Mojo/Fitness System
```typescript
// Mojo: -2 to +2 (5 levels)
// "Locked In" = HIGH (+1) display name
const MOJO_STAT_MULTIPLIERS = {
  RATTLED: 0.82,  // -2
  DOWN: 0.91,     // -1
  NORMAL: 1.00,   // 0
  HIGH: 1.09,     // +1 (Locked In)
  JACKED: 1.18    // +2
};

// Fitness: 6 states
const FITNESS_STAT_MULTIPLIERS = {
  JUICED: 1.20,   // PED bonus, but -50% Fame
  FIT: 1.00,
  WELL: 0.95,
  STRAINED: 0.85,
  WEAK: 0.70,
  HURT: 0.00
};
```

### Salary Calculation Weights
```typescript
// Position Players (3:3:2:1:1)
const BATTER_WEIGHTS = {
  power: 0.30,
  contact: 0.30,
  speed: 0.20,
  fielding: 0.10,
  arm: 0.10
};

// Pitchers (1:1:1)
const PITCHER_WEIGHTS = {
  velocity: 0.333,
  junk: 0.333,
  accuracy: 0.333
};
```

### Position Multipliers (Salary)
```typescript
const POSITION_MULTIPLIERS = {
  C: 1.15,   // +15%
  SS: 1.12,  // +12%
  CF: 1.08,  // +8%
  '2B': 1.05,
  '3B': 1.05,
  RF: 1.00,
  LF: 1.00,
  '1B': 0.92, // -8%
  DH: 0.88    // -12%
};
```

---

## Common Errors & Solutions

### Error: "Orphaned calculator/engine"
**Symptom:** Engine exists, tests pass, but feature doesn't work in UI
**Cause:** Engine never called from UI or storage
**Solution:** Tier 2 NFL - trace UI → Storage → Calculator → Display

### Error: Build succeeds but data doesn't persist
**Symptom:** Feature works until page refresh
**Cause:** IndexedDB write not happening
**Solution:** Check that `eventLog.ts` or relevant storage is actually called

### Error: Spec says X but code does Y
**Symptom:** NFL audit finds mismatches
**Solution:** 
1. Update the CODE to match spec, OR
2. Update the SPEC if code is intentionally different (document in DECISIONS_LOG)

### Error: "Season stats not showing"
**Cause:** `aggregateGameToSeason()` only called at game end
**Expected:** Stats appear after game ends, not during

### Error: "WAR calculation wrong"
**Common Cause:** Using 17.87 runsPerWin (Pythagorean) instead of scaled 10×(games/162)
**Solution:** runsPerWin = 10 × (seasonGames / 162)

---

## Recent Bug Fixes (Reference)

| Date | Bug | Fix |
|------|-----|-----|
| Jan 25, 2026 | Balk button exists but SMB4 has no balks | Removed button |
| Jan 25, 2026 | HR shows "Clean" option | Added "Over Fence", "Wall Scraper" |
| Jan 25, 2026 | GO + runner out didn't auto-correct to DP | Added auto-correction |
| Jan 25, 2026 | Defensive sub could create position duplicates | Added validation |
| Jan 25, 2026 | Season not created on first at-bat | Added `getOrCreateSeason()` call |

---

## Key File Locations

| Logic | File | Notes |
|-------|------|-------|
| WAR Calculations | `src/engines/bwarCalculator.ts`, `pwarCalculator.ts`, etc. | All per spec |
| Salary Calculation | `src/engines/salaryCalculator.ts` | 1196 lines, fully spec-compliant |
| Leverage Index | `src/engines/leverageCalculator.ts` | BASE_OUT_LI table |
| Mojo/Fitness | `src/engines/mojoEngine.ts`, `fitnessEngine.ts` | |
| Game Persistence | `src/storage/gameStorage.ts` | IndexedDB |
| Season Aggregation | `src/storage/seasonAggregator.ts` | Game → Season |
| Career Aggregation | `src/storage/milestoneAggregator.ts` | Game → Career |

---

## Adding New Gotchas

When discovering new issues:
1. Add to appropriate section above
2. Include: What happened, Why, How to fix
3. Update "Last Updated" date
4. Consider if this warrants a DECISIONS_LOG entry
