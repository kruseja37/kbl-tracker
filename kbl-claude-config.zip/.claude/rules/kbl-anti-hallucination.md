# KBL Tracker - Anti-Hallucination Protocol

> **MANDATORY. These rules prevent the infinite "it's working" loop.**

---

## Pre-Response Checklist (COMPLETE BEFORE EVERY CLAIM)

Before saying ANYTHING is "working", "complete", "fixed", or "verified":

```
□ Did I run the actual command and see the output? (not "it would show...")
□ Can I paste the actual terminal output right now?
□ Can I provide specific file:line for every step of data flow?
□ Did I check if the function is actually CALLED (not just defined)?
□ Am I making a claim I can PROVE, or am I assuming?
```

**If ANY checkbox is No → Say "UNVERIFIED" not "complete"**

---

## The Core Problem

Claude has a tendency to:
1. Claim code works without external verification
2. "Verify" by re-reading its own output (circular reasoning)
3. Skip Tier 2 NFL (data flow) which catches orphaned code
4. Lose context about what's actually broken after compaction

**This creates an infinite loop where Claude repeatedly says "fixed" but nothing changes.**

---

## MANDATORY: Proof-Based Verification

### Rule 1: No Claiming "Works" Without External Evidence

**NEVER say any of these without PROOF:**
- ❌ "This should work"
- ❌ "The feature is complete"
- ❌ "I've verified this works"
- ❌ "Everything is functioning correctly"

**ALWAYS require one of these BEFORE claiming success:**
- ✅ `npm run build` exit 0 (show the actual output)
- ✅ `npm test` with passing count (show the actual output)
- ✅ Browser screenshot showing the feature working
- ✅ Console output showing data flow
- ✅ IndexedDB inspection showing persisted data

### Rule 2: External Verification Required

**For any feature implementation, you MUST:**

1. **Run the build** - Paste actual terminal output, not "build passed"
2. **Run relevant tests** - Paste actual test output
3. **Use browser MCP** - Take screenshot of feature in action
4. **Check storage** - Use browser devtools to verify IndexedDB

**If you cannot do external verification, explicitly state:**
> "I cannot verify this externally. User should test: [specific steps]"

### Rule 3: Trace the Full Path (Anti-Orphan Check)

Before claiming ANY feature works, you MUST provide FILE:LINE evidence for:

```
□ UI INPUT:     [file.tsx]:[line] - Component that collects data
□ STORAGE:      [file.ts]:[line] - Function that writes to IndexedDB
□ CALLED FROM:  [file.tsx]:[line] - Where storage function is invoked
□ CALCULATOR:   [file.ts]:[line] - Engine that processes data
□ CALLED FROM:  [file.tsx]:[line] - Where calculator is invoked
□ DISPLAY:      [file.tsx]:[line] - Component that shows result
□ RENDERS IN:   [file.tsx]:[line] - Where display component is used
```

**If ANY box cannot be filled with a specific file:line, the feature is INCOMPLETE.**

### Rule 4: Assume Broken Until Proven Working

**Default stance: The code is broken.**

To override this, provide:
1. Build output (actual terminal text)
2. Test output (actual terminal text)
3. Screenshot or external verification
4. Complete file:line trace

**Without all 4, status remains: "UNVERIFIED"**

---

## Red Flags That Trigger Verification

When you catch yourself saying:

| Red Flag Phrase | Required Action |
|-----------------|-----------------|
| "This should work" | STOP. Run external verification. |
| "I've implemented X" | STOP. Show file:line trace. |
| "The feature is ready" | STOP. Prove with screenshot/test output. |
| "I verified that..." | STOP. Show the actual verification output. |
| "Everything is connected" | STOP. Provide full path trace. |

---

## Orphaned Code Detection

**Orphaned code is the #1 cause of "works but doesn't work".**

Signs of orphaned code:
- Calculator exists but is never imported anywhere
- Type is defined but no UI collects that data
- Storage function exists but nothing calls it
- Display component exists but isn't rendered

**MANDATORY CHECK before claiming feature complete:**

```bash
# Search for the function/component name
grep -r "functionName" src/

# If only found in its own file + maybe tests, it's ORPHANED
```

---

## Compaction Survival Protocol

**Critical context that MUST be written to files before compaction:**

1. **What's actually broken** - Not "some issues remain" but SPECIFIC failures
2. **What was tried** - Prevent re-trying failed approaches
3. **File:line of the problem** - Exact location, not "somewhere in X"
4. **External verification results** - Actual test output, screenshots

**Before ANY compaction, write to CURRENT_STATE.md:**

```markdown
## CRITICAL: Known Issues (Do Not Lose)

### [Feature] is NOT WORKING because:
- Specific reason: [exact problem]
- Location: [file:line]
- Evidence: [test output / screenshot / behavior]
- Attempted fixes that FAILED: [list]
```

---

## The Verification Checklist

**Use this EVERY TIME before saying "complete":**

```
VERIFICATION CHECKLIST FOR: [Feature Name]

BUILD:
□ `npm run build` → Exit code: ___
□ Paste output: [actual terminal output]

TESTS:
□ `npm test` → Passing: ___ / ___
□ Relevant test names: [list]
□ Paste output: [actual terminal output]

DATA FLOW TRACE:
□ UI Input: [file:line]
□ Storage Write: [file:line] called from [file:line]
□ Calculator: [file:line] called from [file:line]
□ Display: [file:line] rendered in [file:line]

EXTERNAL VERIFICATION:
□ Browser test: [screenshot taken / not possible]
□ IndexedDB check: [data present / not checked]
□ Console errors: [none / list them]

VERDICT:
□ ALL boxes checked with evidence → VERIFIED COMPLETE
□ ANY box missing → UNVERIFIED (list what's missing)
```

---

## What To Do When Stuck in a Loop

If you've "fixed" something multiple times and it's still broken:

1. **STOP trying to fix it**
2. **Document EXACTLY what's broken** (not vague, specific)
3. **Document WHAT YOU TRIED** (all attempts)
4. **Ask user for external verification** with specific test steps
5. **Wait for user feedback** before trying again

**Template:**

```
## STUCK: [Feature] Not Working After [N] Attempts

### What's broken:
[Specific behavior - not "it doesn't work" but what exactly fails]

### What I tried:
1. [Attempt 1] - Result: [what happened]
2. [Attempt 2] - Result: [what happened]

### What I need:
User to test: [specific steps] and report:
- Does [X] appear?
- Does [Y] happen when you click [Z]?
- What shows in browser console?

### I will NOT attempt another fix until I get this feedback.
```

---

## Summary: The Anti-Hallucination Rules

1. **Never claim "works" without external proof**
2. **Always provide file:line trace for data flow**
3. **Assume broken until proven otherwise**
4. **Write critical failures to files before compaction**
5. **When stuck, STOP and ask for external verification**
6. **Use the verification checklist every time**

**If you cannot provide proof, say "UNVERIFIED" not "complete".**
