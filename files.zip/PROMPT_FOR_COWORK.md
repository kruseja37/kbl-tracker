# Cowork Prompt: Generate Ralph-Style Development Specs

## Instructions for Claude Cowork

You have access to my KBL Tracker project. Your task is to read my existing spec documentation and generate a complete Ralph-style development specification for UI implementation.

---

## Step 0: Verify Project Setup

Before generating specs, check the project configuration:

1. **Check `package.json`** for:
   - React version
   - Styling approach (Tailwind CSS, CSS modules, styled-components, etc.)
   - UI component libraries (if any)

2. **Check existing components in `src/`** for:
   - File naming conventions
   - Component structure patterns
   - Styling approach actually used

3. **If Tailwind is NOT installed**, note this and include installation as the first story:
   ```
   npm install -D tailwindcss postcss autoprefixer
   npx tailwindcss init -p
   ```

4. **Report findings** before proceeding:
   - "Tech stack found: [React version], [styling approach]"
   - "Existing patterns: [component structure observed]"
   - "Missing dependencies: [if any]"

---

## Step 1: Read These Files First

Read the following files to understand current project state:
1. `spec-docs/CURRENT_STATE.md` - What's implemented, what's not
2. `spec-docs/REQUIREMENTS.md` - User requirements
3. `spec-docs/SESSION_LOG.md` - Recent decisions and context
4. `spec-docs/DECISIONS_LOG.md` - Key architectural decisions
5. Any existing component files in `src/` to understand current patterns

---

## Step 2: Identify UI Components Needed

Based on the spec docs, identify ALL UI components that need to be built.

Create a list in this format:
```
## UI Components Inventory

### High Priority (Needed for Core Flow)
- [ ] [Component Name] - [One sentence description]

### Medium Priority (Important but not blocking)
- [ ] [Component Name] - [One sentence description]

### Lower Priority (Nice to have)
- [ ] [Component Name] - [One sentence description]
```

---

## Step 3: Generate PRDs

For EACH component identified, create a PRD following this exact structure:

```markdown
## [FEATURE_ID]: [Feature Name]

### Overview
[2-3 sentences describing what this feature does and why it exists]

### User Problem
[What problem does this solve for the user?]

### Success Metrics
- [ ] [Measurable outcome 1]
- [ ] [Measurable outcome 2]

### Scope
**In Scope:**
- [Specific item 1]
- [Specific item 2]

**Out of Scope:**
- [Explicitly excluded item 1]

### Dependencies
- [Other features/components this depends on]

### Technical Constraints
- [From existing codebase patterns]
```

---

## Step 4: Break Into User Stories

For each PRD, generate user stories that are **SMALL ENOUGH TO COMPLETE IN ONE CONTEXT WINDOW**.

### Sizing Rules (MUST FOLLOW)
- Each story: < 200 lines of code to implement
- Each story: Maximum 3 acceptance criteria  
- Each story: No architectural decisions required
- Each story: Clear, testable end state

### Story Template
```markdown
## [STORY_ID]: [Short Descriptive Title]

**Parent Feature:** [FEATURE_ID]
**Priority:** [P0/P1/P2]
**Estimated Size:** [Small/Medium]

**As a** [user type]
**I want to** [action/capability]  
**So that** [benefit/outcome]

### Size Check ✓
- [ ] Can be implemented in < 200 lines of code
- [ ] Has no more than 3 acceptance criteria
- [ ] Does not require architectural decisions
- [ ] Has clear, testable end state

### Technical Notes
[Brief implementation hints based on existing codebase patterns]
```

### Common Story Splits for UI Components:
1. Static Structure - HTML/JSX with placeholder data
2. Styling - CSS/Tailwind to match design intent
3. State Management - Local state and handlers
4. Data Integration - Connect to real data/store
5. Validation/Error States - Edge cases

---

## Step 5: Write Acceptance Criteria

For EACH story, write acceptance criteria that are **OBJECTIVELY VERIFIABLE**.

### Criteria Template
```markdown
### Acceptance Criteria for [STORY_ID]

**AC-1: [Criterion Name]**
- **Given:** [Initial state/precondition]
- **When:** [Action taken]
- **Then:** [Expected observable outcome]
- **Verify:** [Exact steps to confirm]

**AC-2: [Criterion Name]**
- **Given:** [Initial state/precondition]
- **When:** [Action taken]
- **Then:** [Expected observable outcome]
- **Verify:** [Exact steps to confirm]
```

### Criteria Rules (MUST FOLLOW)
- NO subjective language: "looks good", "works well", "clean", "proper"
- YES specific language: "button is 44px tall", "field shows error text", "list displays 5 items"
- MUST include exact verification steps
- MUST reference specific UI elements or data values

---

## Step 6: Generate Implementation Order

Create an ordered list showing which stories to implement first, based on:
1. Dependencies (what needs to exist before other things can be built)
2. Priority (core flow vs. nice-to-have)
3. Testability (can't test feature X until feature Y exists)

Format:
```markdown
## Implementation Order

### Phase 1: Foundation
1. [STORY_ID] - [Title] - [Why first]
2. [STORY_ID] - [Title] - [Depends on #1]

### Phase 2: Core Features  
3. [STORY_ID] - [Title]
4. [STORY_ID] - [Title]

### Phase 3: Polish
5. [STORY_ID] - [Title]
```

---

## Step 7: Output Files to Create

Generate these files in `spec-docs/ralph/`:

1. `UI_INVENTORY.md` - Component inventory from Step 2
2. `PRD_UI_COMPONENTS.md` - All PRDs from Step 3
3. `USER_STORIES.md` - All stories from Step 4
4. `ACCEPTANCE_CRITERIA.md` - All criteria from Step 5
5. `IMPLEMENTATION_ORDER.md` - Ordered list from Step 6

---

## Quality Checklist Before Finishing

- [ ] Every story has a parent feature ID
- [ ] Every story passes the size check
- [ ] Every acceptance criterion is objectively verifiable
- [ ] No story has more than 3 acceptance criteria
- [ ] Implementation order accounts for all dependencies
- [ ] Terminology matches existing codebase (check src/ files)

---

## Questions to Surface

If you encounter any of these, STOP and ask me:
- Ambiguous requirements that could be interpreted multiple ways
- Missing information about expected behavior
- Conflicts between different parts of the spec docs
- Uncertainty about technical approach (should be noted, not decided)

---

## Example Output Quality

### ❌ Bad Story (too vague, too big)
> "As a user, I want to see my transactions so I can track spending"

### ✅ Good Story (specific, small)
> "As a user viewing the transaction list, I want to see each transaction's date displayed in MM/DD format so I can quickly identify when purchases occurred"

### ❌ Bad Criteria (subjective)
> "The list should look clean and load quickly"

### ✅ Good Criteria (objective)
> "Given 10 transactions exist, When the list renders, Then all 10 rows are visible within 500ms of component mount"

---

## Begin

Start by reading the spec-docs files listed in Step 1, then proceed through each step. Create the output files in `spec-docs/ralph/`. Ask clarifying questions if anything is ambiguous.
