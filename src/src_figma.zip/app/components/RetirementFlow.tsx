import { useState, useEffect } from "react";
import { ArrowLeft, Dice1, Dice2, Dice3, Dice4, Dice5, Dice6, Trophy, CheckCircle, X } from "lucide-react";

// Types
type Position = "SP" | "CP" | "C" | "1B" | "2B" | "3B" | "SS" | "LF" | "CF" | "RF";
type Grade = "A+" | "A" | "A-" | "B+" | "B" | "B-" | "C+" | "C" | "C-";

interface Player {
  id: string;
  name: string;
  position: Position;
  grade: Grade;
  age: number;
  seasons: number;
  war: number;
  teamId: string;
  jerseyNumber: number;
  awards: string[];
  careerStats: string;
}

interface Team {
  id: string;
  name: string;
  shortName: string;
  primaryColor: string;
  secondaryColor: string;
}

interface PlayerHistory {
  teamId: string;
  seasons: number;
  war: number;
  awards: string[];
  jerseyNumber: number;
}

interface Retirement {
  player: Player;
  team: Team;
  jerseyRetirements: string[]; // team IDs where jersey is retired
}

type Screen = 
  | "PROBABILITY" 
  | "ROLLING" 
  | "NO_RETIREMENT" 
  | "RETIREMENT_ANNOUNCEMENT" 
  | "JERSEY_DECISION"
  | "JERSEY_CEREMONY"
  | "PHASE_SUMMARY";

// Mock Data
const TEAMS: Team[] = [
  { id: "thunder", name: "New York Thunder", shortName: "THUNDER", primaryColor: "#DD0000", secondaryColor: "#0066FF" },
  { id: "redsox", name: "Boston Red Sox", shortName: "SOX", primaryColor: "#DD0000", secondaryColor: "#003087" },
  { id: "giants", name: "San Francisco Giants", shortName: "GIANTS", primaryColor: "#FD5A1E", secondaryColor: "#27251F" },
  { id: "mariners", name: "Seattle Mariners", shortName: "MARINERS", primaryColor: "#0C2C56", secondaryColor: "#005C5C" },
  { id: "rockies", name: "Colorado Rockies", shortName: "ROCKIES", primaryColor: "#33006F", secondaryColor: "#C4CED4" },
  { id: "dodgers", name: "Los Angeles Dodgers", shortName: "DODGERS", primaryColor: "#005A9C", secondaryColor: "#EF3E42" },
  { id: "cubs", name: "Chicago Cubs", shortName: "CUBS", primaryColor: "#0E3386", secondaryColor: "#CC3433" },
  { id: "astros", name: "Houston Astros", shortName: "ASTROS", primaryColor: "#EB6E1F", secondaryColor: "#002D62" },
];

const MOCK_PLAYERS: Player[] = [
  { id: "p1", name: "Roger Clemens", position: "SP", grade: "A", age: 42, seasons: 20, war: 139.4, teamId: "thunder", jerseyNumber: 21, awards: ["7× Cy Young", "2× MVP"], careerStats: "354 Wins | 3.12 ERA | 4,672 K" },
  { id: "p2", name: "Tony Gwynn", position: "RF", grade: "A-", age: 39, seasons: 18, war: 69.2, teamId: "giants", jerseyNumber: 19, awards: ["8× Batting Champ"], careerStats: ".338 AVG | 3,141 Hits | 319 SB" },
  { id: "p3", name: "Mark McGwire", position: "1B", grade: "B+", age: 37, seasons: 16, war: 62.1, teamId: "giants", jerseyNumber: 25, awards: ["12× All-Star"], careerStats: "583 HR | .263 AVG | 1,414 RBI" },
  { id: "p4", name: "Barry Bonds", position: "LF", grade: "A+", age: 35, seasons: 15, war: 162.8, teamId: "giants", jerseyNumber: 25, awards: ["5× MVP", "8× Gold Glove"], careerStats: ".298 AVG | 514 HR | 1,299 RBI" },
  { id: "p5", name: "Ken Griffey Jr.", position: "CF", grade: "A", age: 33, seasons: 12, war: 83.8, teamId: "mariners", jerseyNumber: 24, awards: ["MVP", "10× Gold Glove"], careerStats: ".292 AVG | 398 HR | 1,152 RBI" },
  { id: "p6", name: "Derek Jeter", position: "SS", grade: "A-", age: 30, seasons: 10, war: 72.4, teamId: "thunder", jerseyNumber: 2, awards: ["5× World Series", "14× All-Star"], careerStats: ".314 AVG | 260 HR | 1,311 RBI" },
  { id: "p7", name: "Alex Rodriguez", position: "3B", grade: "A", age: 28, seasons: 8, war: 117.5, teamId: "thunder", jerseyNumber: 13, awards: ["3× MVP", "14× All-Star"], careerStats: ".300 AVG | 696 HR | 2,086 RBI" },
  { id: "p8", name: "Mike Trout", position: "CF", grade: "B+", age: 22, seasons: 4, war: 72.8, teamId: "thunder", jerseyNumber: 27, awards: ["3× MVP", "9× All-Star"], careerStats: ".305 AVG | 350 HR | 899 RBI" },
  { id: "p9", name: "Randy Johnson", position: "SP", grade: "A-", age: 41, seasons: 19, war: 104.3, teamId: "mariners", jerseyNumber: 51, awards: ["5× Cy Young"], careerStats: "303 Wins | 3.29 ERA | 4,875 K" },
  { id: "p10", name: "Pedro Martinez", position: "SP", grade: "B+", age: 38, seasons: 16, war: 86.0, teamId: "redsox", jerseyNumber: 45, awards: ["3× Cy Young"], careerStats: "219 Wins | 2.93 ERA | 3,154 K" },
  { id: "p11", name: "Greg Maddux", position: "SP", grade: "B+", age: 36, seasons: 18, war: 106.6, teamId: "cubs", jerseyNumber: 31, awards: ["4× Cy Young"], careerStats: "355 Wins | 3.16 ERA | 3,371 K" },
  { id: "p12", name: "Mariano Rivera", position: "CP", grade: "B", age: 34, seasons: 12, war: 56.6, teamId: "thunder", jerseyNumber: 42, awards: ["5× World Series"], careerStats: "652 SV | 2.21 ERA | 1,173 K" },
  { id: "p13", name: "David Ortiz", position: "1B", grade: "A", age: 32, seasons: 10, war: 55.3, teamId: "redsox", jerseyNumber: 34, awards: ["10× All-Star"], careerStats: ".286 AVG | 541 HR | 1,768 RBI" },
  { id: "p14", name: "Manny Ramirez", position: "LF", grade: "A-", age: 31, seasons: 11, war: 69.3, teamId: "redsox", jerseyNumber: 24, awards: ["12× All-Star"], careerStats: ".312 AVG | 555 HR | 1,831 RBI" },
  { id: "p15", name: "Jason Varitek", position: "C", grade: "B+", age: 29, seasons: 9, war: 34.1, teamId: "redsox", jerseyNumber: 33, awards: ["3× All-Star"], careerStats: ".256 AVG | 193 HR | 757 RBI" },
  { id: "p16", name: "Curt Schilling", position: "SP", grade: "A-", age: 37, seasons: 17, war: 79.9, teamId: "redsox", jerseyNumber: 38, awards: ["6× All-Star"], careerStats: "216 Wins | 3.46 ERA | 3,116 K" },
  { id: "p17", name: "Todd Helton", position: "1B", grade: "A-", age: 33, seasons: 12, war: 61.8, teamId: "rockies", jerseyNumber: 17, awards: ["5× All-Star"], careerStats: ".316 AVG | 369 HR | 1,406 RBI" },
  { id: "p18", name: "Larry Walker", position: "RF", grade: "A", age: 36, seasons: 15, war: 72.7, teamId: "rockies", jerseyNumber: 33, awards: ["MVP", "7× All-Star"], careerStats: ".313 AVG | 383 HR | 1,311 RBI" },
];

// Calculate retirement probability based on age
function calculateRetirementProbability(age: number): number {
  if (age >= 42) return 47;
  if (age >= 41) return 42;
  if (age >= 40) return 38;
  if (age >= 39) return 35;
  if (age >= 38) return 31;
  if (age >= 37) return 27;
  if (age >= 36) return 23;
  if (age >= 35) return 19;
  if (age >= 34) return 16;
  if (age >= 33) return 14;
  if (age >= 32) return 12;
  if (age >= 31) return 10;
  if (age >= 30) return 8;
  if (age >= 29) return 7;
  if (age >= 28) return 6;
  if (age >= 27) return 5;
  if (age >= 26) return 4;
  if (age >= 25) return 3;
  return 2;
}

// Get probability bar color based on percentage
function getProbabilityColor(probability: number): string {
  if (probability >= 40) return "#DC143C"; // Red
  if (probability >= 25) return "#FFA500"; // Orange
  if (probability >= 15) return "#FFD700"; // Yellow
  if (probability >= 5) return "#228B22"; // Green
  return "#4682B4"; // Blue
}

// Get grade color
function getGradeColor(grade: Grade): string {
  const tier = { "A+": 10, "A": 9, "A-": 8, "B+": 7, "B": 6, "B-": 5, "C+": 4, "C": 3, "C-": 2 }[grade];
  if (tier >= 8) return "#228B22";
  if (tier >= 5) return "#4682B4";
  return "#CD853F";
}

// Generate flavor text for retirement announcement
function getFlavorText(player: Player): string {
  if (player.age >= 40) return `Going out on top after ${player.seasons} seasons`;
  if (player.age >= 35) return "Hanging up the cleats while still in his prime";
  if (player.age >= 30) return "A career cut short, but what a career it was";
  if (player.war > 100) return "One of the all-time greats calls it a career";
  if (player.seasons >= 15) return "A franchise legend says goodbye";
  if (player.awards.some(a => a.includes("MVP"))) return "An MVP-caliber career comes to a close";
  return "A journeyman's journey comes to an end";
}

// Roll retirement dice for a roster
function rollRetirement(roster: Player[]): Player | null {
  // Calculate cumulative probabilities
  const probabilities = roster.map(p => calculateRetirementProbability(p.age));
  const totalProbability = probabilities.reduce((sum, p) => sum + p, 0);
  
  // Roll dice (0-100)
  const roll = Math.random() * 100;
  
  // Check if anyone retires
  let cumulative = 0;
  for (let i = 0; i < roster.length; i++) {
    cumulative += (probabilities[i] / totalProbability) * 50; // 50% base chance someone retires
    if (roll < cumulative) {
      return roster[i];
    }
  }
  
  return null;
}

interface RetirementFlowProps {
  onClose: () => void;
  onRetirementsComplete?: (retiredJerseys: Array<{
    number: number;
    name: string;
    years: string;
    position: string;
    teamId: string;
    retiredYear: number;
  }>) => void;
}

export function RetirementFlow({ onClose, onRetirementsComplete }: RetirementFlowProps) {
  const [screen, setScreen] = useState<Screen>("PROBABILITY");
  const [currentTeamIndex, setCurrentTeamIndex] = useState(0);
  const [retirements, setRetirements] = useState<Retirement[]>([]);
  const [currentRetiredPlayer, setCurrentRetiredPlayer] = useState<Player | null>(null);
  const [retirementsThisTeam, setRetirementsThisTeam] = useState(0);
  const [selectedJerseyTeams, setSelectedJerseyTeams] = useState<string[]>([]);
  const [ceremonyTeamIndex, setCeremonyTeamIndex] = useState(0);
  const [isRolling, setIsRolling] = useState(false);

  const currentTeam = TEAMS[currentTeamIndex];
  
  // Get roster for current team
  const getTeamRoster = (teamId: string): Player[] => {
    return MOCK_PLAYERS.filter(p => p.teamId === teamId);
  };

  const currentRoster = getTeamRoster(currentTeam.id);

  // Handle dice roll
  const handleRoll = () => {
    setScreen("ROLLING");
    setIsRolling(true);

    setTimeout(() => {
      const retiredPlayer = rollRetirement(currentRoster);
      
      if (retiredPlayer) {
        setCurrentRetiredPlayer(retiredPlayer);
        setRetirementsThisTeam(retirementsThisTeam + 1);
        setScreen("RETIREMENT_ANNOUNCEMENT");
      } else {
        setScreen("NO_RETIREMENT");
      }
      
      setIsRolling(false);
    }, 2000);
  };

  // Advance to jersey decision
  const handleProceedToJersey = () => {
    setScreen("JERSEY_DECISION");
  };

  // Skip jersey retirement
  const handleSkipJersey = () => {
    if (currentRetiredPlayer) {
      const retirement: Retirement = {
        player: currentRetiredPlayer,
        team: currentTeam,
        jerseyRetirements: [],
      };
      setRetirements([...retirements, retirement]);
    }
    advanceToNextTeam();
  };

  // Confirm jersey retirements
  const handleConfirmJersey = () => {
    if (selectedJerseyTeams.length > 0) {
      setCeremonyTeamIndex(0);
      setScreen("JERSEY_CEREMONY");
    } else {
      handleSkipJersey();
    }
  };

  // Continue from jersey ceremony
  const handleContinueFromCeremony = () => {
    if (ceremonyTeamIndex < selectedJerseyTeams.length - 1) {
      setCeremonyTeamIndex(ceremonyTeamIndex + 1);
    } else {
      // All ceremonies complete
      if (currentRetiredPlayer) {
        const retirement: Retirement = {
          player: currentRetiredPlayer,
          team: currentTeam,
          jerseyRetirements: selectedJerseyTeams,
        };
        setRetirements([...retirements, retirement]);
      }
      advanceToNextTeam();
    }
  };

  // Try another roll
  const handleTryAgain = () => {
    if (retirementsThisTeam < 2) {
      setScreen("PROBABILITY");
    } else {
      advanceToNextTeam();
    }
  };

  // Skip to next team
  const handleSkipToNext = () => {
    advanceToNextTeam();
  };

  // Advance to next team
  const advanceToNextTeam = () => {
    if (currentTeamIndex < TEAMS.length - 1) {
      setCurrentTeamIndex(currentTeamIndex + 1);
      setScreen("PROBABILITY");
      setCurrentRetiredPlayer(null);
      setRetirementsThisTeam(0);
      setSelectedJerseyTeams([]);
      setCeremonyTeamIndex(0);
    } else {
      setScreen("PHASE_SUMMARY");
      if (onRetirementsComplete) {
        const retiredJerseys = retirements.flatMap(retirement => 
          retirement.jerseyRetirements.map(teamId => ({
            number: retirement.player.jerseyNumber,
            name: retirement.player.name,
            years: `${retirement.player.seasons} seasons`,
            position: retirement.player.position,
            teamId: teamId,
            retiredYear: 2026,
          }))
        );
        onRetirementsComplete(retiredJerseys);
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-black/95 z-50 overflow-y-auto">
      <div className="min-h-screen p-4">
        {/* Header */}
        <div className="max-w-5xl mx-auto mb-4 flex items-center justify-between">
          <button
            onClick={onClose}
            className="flex items-center gap-2 text-[#E8E8D8] hover:text-[#DD0000] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="text-sm">Back</span>
          </button>
          <div className="text-center">
            <div className="text-xl text-[#E8E8D8]">RETIREMENTS - Phase 5</div>
            {screen !== "PHASE_SUMMARY" && (
              <div className="text-xs text-[#E8E8D8]/60">Team {currentTeamIndex + 1} of {TEAMS.length}</div>
            )}
          </div>
          <div className="w-20"></div>
        </div>

        {/* Main Content */}
        <div className="max-w-5xl mx-auto">
          {screen === "PROBABILITY" && (
            <ProbabilityScreen
              team={currentTeam}
              roster={currentRoster}
              retirementsThisTeam={retirementsThisTeam}
              onRoll={handleRoll}
            />
          )}

          {screen === "ROLLING" && (
            <RollingScreen />
          )}

          {screen === "NO_RETIREMENT" && (
            <NoRetirementScreen
              retirementsThisTeam={retirementsThisTeam}
              onTryAgain={handleTryAgain}
              onSkipToNext={handleSkipToNext}
            />
          )}

          {screen === "RETIREMENT_ANNOUNCEMENT" && currentRetiredPlayer && (
            <RetirementAnnouncementScreen
              player={currentRetiredPlayer}
              retirementsThisTeam={retirementsThisTeam}
              onProceedToJersey={handleProceedToJersey}
              onSecondRoll={retirementsThisTeam < 2 ? handleTryAgain : undefined}
            />
          )}

          {screen === "JERSEY_DECISION" && currentRetiredPlayer && (
            <JerseyDecisionScreen
              player={currentRetiredPlayer}
              selectedTeams={selectedJerseyTeams}
              onToggleTeam={(teamId) => {
                if (selectedJerseyTeams.includes(teamId)) {
                  setSelectedJerseyTeams(selectedJerseyTeams.filter(t => t !== teamId));
                } else {
                  setSelectedJerseyTeams([...selectedJerseyTeams, teamId]);
                }
              }}
              onSkip={handleSkipJersey}
              onConfirm={handleConfirmJersey}
            />
          )}

          {screen === "JERSEY_CEREMONY" && currentRetiredPlayer && (
            <JerseyCeremonyScreen
              player={currentRetiredPlayer}
              team={TEAMS.find(t => t.id === selectedJerseyTeams[ceremonyTeamIndex])!}
              onContinue={handleContinueFromCeremony}
            />
          )}

          {screen === "PHASE_SUMMARY" && (
            <PhaseSummaryScreen
              retirements={retirements}
              onClose={onClose}
            />
          )}
        </div>
      </div>
    </div>
  );
}

// Screen: Probability Table
function ProbabilityScreen({
  team,
  roster,
  retirementsThisTeam,
  onRoll,
}: {
  team: Team;
  roster: Player[];
  retirementsThisTeam: number;
  onRoll: () => void;
}) {
  const sortedRoster = [...roster].sort((a, b) => 
    calculateRetirementProbability(b.age) - calculateRetirementProbability(a.age)
  );

  return (
    <div className="space-y-4">
      {/* Team Header */}
      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-6">
        <div className="flex items-center gap-4 mb-4">
          <div 
            className="w-16 h-16 rounded-full flex items-center justify-center text-2xl text-white font-bold"
            style={{ backgroundColor: team.primaryColor }}
          >
            {team.shortName[0]}
          </div>
          <div>
            <div className="text-xl text-[#E8E8D8]">{team.name}</div>
          </div>
        </div>
        <div className="text-sm text-[#E8E8D8]/80">
          Review retirement probabilities for this team. Older players have higher chances of retiring.
        </div>
      </div>

      {/* Probability Table */}
      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="text-lg text-[#E8E8D8]">📊 RETIREMENT PROBABILITIES</div>
          <div className="text-xs text-[#E8E8D8]/60">Sorted by Risk ▼</div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b-2 border-[#E8E8D8]/20">
                <th className="text-left py-2 px-3 text-[#E8E8D8]/80">AGE</th>
                <th className="text-left py-2 px-3 text-[#E8E8D8]/80">PLAYER</th>
                <th className="text-left py-2 px-3 text-[#E8E8D8]/80">POS</th>
                <th className="text-left py-2 px-3 text-[#E8E8D8]/80">GRADE</th>
                <th className="text-left py-2 px-3 text-[#E8E8D8]/80">RETIRE %</th>
              </tr>
            </thead>
            <tbody>
              {sortedRoster.map((player) => {
                const probability = calculateRetirementProbability(player.age);
                const color = getProbabilityColor(probability);
                
                return (
                  <tr key={player.id} className="border-b border-[#E8E8D8]/10">
                    <td className="py-3 px-3 text-[#E8E8D8] font-bold text-center">{player.age}</td>
                    <td className="py-3 px-3 text-[#E8E8D8]">{player.name}</td>
                    <td className="py-3 px-3 text-[#E8E8D8]/60">{player.position}</td>
                    <td className="py-3 px-3">
                      <span
                        className="px-2 py-1 text-xs text-white rounded"
                        style={{ backgroundColor: getGradeColor(player.grade) }}
                      >
                        {player.grade}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 max-w-[120px] bg-[#E8E8D8]/20 h-4 rounded overflow-hidden">
                          <div
                            className="h-full"
                            style={{ 
                              width: `${(probability / 50) * 100}%`,
                              backgroundColor: color 
                            }}
                          ></div>
                        </div>
                        <span className="text-xs text-[#E8E8D8]/80 w-12">{probability}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Status Footer */}
      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-4">
        <div className="flex items-center justify-between text-sm text-[#E8E8D8]">
          <div>Retirements this team: <span className="font-bold">{retirementsThisTeam}/2</span></div>
          <div className="text-[#E8E8D8]/60">Target: 1-2 per team</div>
        </div>
      </div>

      {/* Roll Button */}
      <button
        onClick={onRoll}
        className="w-full bg-[#5A8352] border-[5px] border-[#4A6844] py-4 text-lg text-[#E8E8D8] hover:bg-[#4F7D4B] active:scale-95 transition-transform shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)]"
      >
        🎲 REVEAL RETIREMENT 🎲
      </button>

      <div className="text-center text-xs text-[#E8E8D8]/60">
        Roll to see if anyone retires. Probability determines who.
      </div>
    </div>
  );
}

// Screen: Rolling Animation
function RollingScreen() {
  return (
    <div className="space-y-8 py-12">
      <div className="text-center">
        <div className="w-32 h-32 mx-auto mb-6 animate-bounce">
          <div className="text-8xl">🎲</div>
        </div>
        <div className="text-2xl text-[#E8E8D8] mb-2">Rolling...</div>
        <div className="text-sm text-[#E8E8D8]/60">Checking retirement rolls...</div>
      </div>

      <div className="max-w-md mx-auto bg-[#5A8352] border-[5px] border-[#C4A853] p-4">
        <div className="bg-[#4A6844] h-6 rounded overflow-hidden">
          <div className="h-full bg-[#E8E8D8] animate-pulse" style={{ width: '60%' }}></div>
        </div>
        <div className="text-center text-xs text-[#E8E8D8]/60 mt-2">▲ Scanning roster...</div>
      </div>
    </div>
  );
}

// Screen: No Retirement
function NoRetirementScreen({
  retirementsThisTeam,
  onTryAgain,
  onSkipToNext,
}: {
  retirementsThisTeam: number;
  onTryAgain: () => void;
  onSkipToNext: () => void;
}) {
  return (
    <div className="space-y-6 py-12">
      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-12 text-center">
        <div className="text-6xl mb-4">✓</div>
        <div className="text-2xl text-[#E8E8D8] mb-4">NO RETIREMENT</div>
        <div className="text-base text-[#E8E8D8]/80">
          The dice rolled in their favor — everyone stays!
        </div>
      </div>

      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-4">
        <div className="text-sm text-[#E8E8D8] text-center">
          Retirements this team: <span className="font-bold">{retirementsThisTeam}/2</span>
        </div>
      </div>

      <div className="flex gap-4">
        {retirementsThisTeam < 2 && (
          <button
            onClick={onTryAgain}
            className="flex-1 bg-[#4A6844] border-[5px] border-[#5A8352] py-3 text-base text-[#E8E8D8] hover:bg-[#3F5A3A] active:scale-95 transition-transform shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)]"
          >
            🎲 TRY AGAIN
          </button>
        )}
        <button
          onClick={onSkipToNext}
          className="flex-1 bg-[#5A8352] border-[5px] border-[#4A6844] py-3 text-base text-[#E8E8D8] hover:bg-[#4F7D4B] active:scale-95 transition-transform shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)]"
        >
          SKIP TO NEXT TEAM →
        </button>
      </div>

      <div className="text-center text-xs text-[#E8E8D8]/60">
        Each team may have 0-2 retirements. No retirement is valid.
      </div>
    </div>
  );
}

// Screen: Retirement Announcement
function RetirementAnnouncementScreen({
  player,
  retirementsThisTeam,
  onProceedToJersey,
  onSecondRoll,
}: {
  player: Player;
  retirementsThisTeam: number;
  onProceedToJersey: () => void;
  onSecondRoll?: () => void;
}) {
  const flavorText = getFlavorText(player);

  return (
    <div className="space-y-6">
      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-6 text-center">
        <div className="text-2xl text-[#E8E8D8]">🎩 RETIREMENT 🎩</div>
      </div>

      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-12">
        <div className="max-w-md mx-auto text-center space-y-6">
          {/* Player Photo */}
          <div className="w-32 h-32 bg-[#E8E8D8] rounded-full flex items-center justify-center text-4xl mx-auto">
            {player.name.split(' ').map(n => n[0]).join('')}
          </div>

          {/* Player Name */}
          <div>
            <div className="text-3xl text-[#E8E8D8] mb-2">{player.name}</div>
            <div className="text-base text-[#E8E8D8]/80">
              Age {player.age} • {player.position} • Grade {player.grade}
            </div>
          </div>

          {/* Flavor Text */}
          <div className="bg-[#4A6844] border-[3px] border-[#5A8352] p-4 italic text-[#E8E8D8]">
            "{flavorText}"
          </div>

          {/* Career Highlights */}
          <div className="text-left bg-[#4A6844] border-[3px] border-[#5A8352] p-6">
            <div className="text-lg text-[#E8E8D8] mb-3 border-b border-[#E8E8D8]/20 pb-2">
              CAREER HIGHLIGHTS
            </div>
            <div className="space-y-2 text-sm text-[#E8E8D8]/90">
              <div>• {player.seasons} Seasons</div>
              <div>• {player.careerStats}</div>
              {player.awards.map((award, i) => (
                <div key={i}>• {award}</div>
              ))}
              <div>• Career WAR: {player.war.toFixed(1)}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-4">
        <div className="text-sm text-[#E8E8D8] text-center">
          Retirements this team: <span className="font-bold">{retirementsThisTeam}/2</span>
        </div>
      </div>

      <div className="flex gap-4">
        {onSecondRoll && (
          <button
            onClick={onSecondRoll}
            className="flex-1 bg-[#4A6844] border-[5px] border-[#5A8352] py-3 text-base text-[#E8E8D8] hover:bg-[#3F5A3A] active:scale-95 transition-transform shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)]"
          >
            🎲 SECOND ROLL
          </button>
        )}
        <button
          onClick={onProceedToJersey}
          className="flex-1 bg-[#5A8352] border-[5px] border-[#4A6844] py-3 text-base text-[#E8E8D8] hover:bg-[#4F7D4B] active:scale-95 transition-transform shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)]"
        >
          RETIRE JERSEY →
        </button>
      </div>
    </div>
  );
}

// Screen: Jersey Decision
function JerseyDecisionScreen({
  player,
  selectedTeams,
  onToggleTeam,
  onSkip,
  onConfirm,
}: {
  player: Player;
  selectedTeams: string[];
  onToggleTeam: (teamId: string) => void;
  onSkip: () => void;
  onConfirm: () => void;
}) {
  // Mock: player has played for 2 teams
  const teamsPlayedFor = [
    { 
      team: TEAMS[0], 
      seasons: 8, 
      war: 32.1, 
      awards: ["2× Cy Young"],
      jerseyNumber: player.jerseyNumber 
    },
    { 
      team: TEAMS[1], 
      seasons: 12, 
      war: 48.7, 
      awards: ["3× Cy Young", "1× MVP"],
      jerseyNumber: player.jerseyNumber 
    },
  ];

  return (
    <div className="space-y-4">
      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-6 text-center">
        <div className="text-2xl text-[#E8E8D8]">🏆 JERSEY RETIREMENT 🏆</div>
      </div>

      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-6">
        <div className="text-base text-[#E8E8D8] mb-2">
          {player.name} has retired.
        </div>
        <div className="text-sm text-[#E8E8D8]/80">
          Would you like to retire his jersey?
        </div>
      </div>

      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-6">
        <div className="text-lg text-[#E8E8D8] mb-4">TEAMS PLAYED FOR:</div>

        <div className="space-y-3">
          {teamsPlayedFor.map((history) => {
            const isSelected = selectedTeams.includes(history.team.id);
            
            return (
              <button
                key={history.team.id}
                onClick={() => onToggleTeam(history.team.id)}
                className="w-full bg-[#4A6844] border-[3px] border-[#5A8352] p-4 hover:bg-[#3F5A3A] transition-colors text-left"
              >
                <div className="flex items-start gap-4">
                  <div className={`w-8 h-8 rounded border-2 flex items-center justify-center flex-shrink-0 ${isSelected ? 'bg-[#E8E8D8] border-[#E8E8D8]' : 'border-[#E8E8D8]'}`}>
                    {isSelected && <CheckCircle className="w-6 h-6 text-[#228B22]" />}
                  </div>
                  
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0"
                    style={{ backgroundColor: history.team.primaryColor }}
                  >
                    {history.team.shortName[0]}
                  </div>
                  
                  <div className="flex-1">
                    <div className="text-base text-[#E8E8D8] mb-1">
                      {history.team.name} (#{history.jerseyNumber})
                    </div>
                    <div className="text-sm text-[#E8E8D8]/70">
                      {history.seasons} seasons | {history.war.toFixed(1)} WAR | {history.awards.join(" | ")}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="bg-[#4169E1]/20 border-l-4 border-[#4169E1] p-4">
        <div className="flex items-start gap-2 text-sm text-[#E8E8D8]">
          <span className="text-lg">💡</span>
          <div>
            <div className="font-bold mb-1">Retired numbers cannot be reassigned to future players.</div>
            <div className="text-[#E8E8D8]/80">
              This decision is entirely your choice — no eligibility rules.
            </div>
          </div>
        </div>
      </div>

      <div className="flex gap-4">
        <button
          onClick={onSkip}
          className="flex-1 bg-[#4A6844] border-[5px] border-[#5A8352] py-3 text-base text-[#E8E8D8] hover:bg-[#3F5A3A] active:scale-95 transition-transform shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)]"
        >
          SKIP
        </button>
        <button
          onClick={onConfirm}
          disabled={selectedTeams.length === 0}
          className="flex-1 bg-[#5A8352] border-[5px] border-[#4A6844] py-3 text-base text-[#E8E8D8] hover:bg-[#4F7D4B] disabled:opacity-50 disabled:cursor-not-allowed active:scale-95 transition-transform shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)]"
        >
          RETIRE SELECTED
        </button>
      </div>
    </div>
  );
}

// Screen: Jersey Ceremony
function JerseyCeremonyScreen({
  player,
  team,
  onContinue,
}: {
  player: Player;
  team: Team;
  onContinue: () => void;
}) {
  return (
    <div className="space-y-8 py-12">
      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-6 text-center">
        <div className="text-2xl text-[#E8E8D8]">🏆 JERSEY RETIRED 🏆</div>
      </div>

      <div className="text-center">
        {/* Jersey Display */}
        <div 
          className="w-48 h-64 mx-auto rounded-lg border-8 flex flex-col items-center justify-center relative overflow-hidden shadow-[8px_8px_0px_0px_rgba(0,0,0,0.8)]"
          style={{ 
            backgroundColor: team.primaryColor,
            borderColor: team.secondaryColor,
          }}
        >
          <div 
            className="text-2xl font-bold mb-2"
            style={{ color: team.secondaryColor }}
          >
            {player.name.split(' ')[1].toUpperCase()}
          </div>
          <div 
            className="text-7xl font-bold"
            style={{ color: team.secondaryColor }}
          >
            {player.jerseyNumber}
          </div>
        </div>
        
        <div className="text-xl text-[#E8E8D8] mt-6 mb-2">2026</div>
        <div className="text-2xl text-[#E8E8D8] mb-6">{team.name}</div>

        <div className="max-w-md mx-auto border-t border-b border-[#E8E8D8]/20 py-4 mb-8">
          <div className="text-base text-[#E8E8D8] italic">
            "Jersey #{player.jerseyNumber} will hang in the rafters forever at {team.name.split(' ')[0]} Stadium"
          </div>
        </div>
      </div>

      <button
        onClick={onContinue}
        className="max-w-md mx-auto block w-full bg-[#5A8352] border-[5px] border-[#4A6844] py-4 text-lg text-[#E8E8D8] hover:bg-[#4F7D4B] active:scale-95 transition-transform shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)]"
      >
        CONTINUE
      </button>
    </div>
  );
}

// Screen: Phase Summary
function PhaseSummaryScreen({
  retirements,
  onClose,
}: {
  retirements: Retirement[];
  onClose: () => void;
}) {
  const totalRetirements = retirements.length;
  const totalJerseyRetirements = retirements.reduce((sum, r) => sum + r.jerseyRetirements.length, 0);

  return (
    <div className="space-y-4">
      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-6 text-center">
        <div className="text-2xl text-[#E8E8D8] mb-6">RETIREMENT PHASE COMPLETE</div>

        <div className="grid grid-cols-3 gap-4">
          <div className="bg-[#4A6844] border-[3px] border-[#5A8352] p-4">
            <div className="text-3xl text-[#E8E8D8]">{totalRetirements}</div>
            <div className="text-xs text-[#E8E8D8]/60">PLAYERS<br/>Retired</div>
          </div>
          <div className="bg-[#4A6844] border-[3px] border-[#5A8352] p-4">
            <div className="text-3xl text-[#E8E8D8]">{totalJerseyRetirements}</div>
            <div className="text-xs text-[#E8E8D8]/60">JERSEYS<br/>Retired</div>
          </div>
          <div className="bg-[#4A6844] border-[3px] border-[#5A8352] p-4">
            <div className="text-3xl text-[#E8E8D8]">{TEAMS.length}</div>
            <div className="text-xs text-[#E8E8D8]/60">TEAMS<br/>Processed</div>
          </div>
        </div>
      </div>

      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-6">
        <div className="text-lg text-[#E8E8D8] mb-4">RETIREMENTS</div>

        <div className="space-y-2 max-h-[400px] overflow-y-auto">
          {retirements.map((retirement, index) => (
            <div key={index} className="bg-[#4A6844] border-[3px] border-[#5A8352] p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🎩</span>
                  <div>
                    <div className="text-base text-[#E8E8D8]">
                      {retirement.player.name} ({retirement.player.position}, {retirement.player.grade})
                    </div>
                    <div className="text-sm text-[#E8E8D8]/60">
                      {retirement.team.shortName}
                    </div>
                  </div>
                </div>
                <div className="text-sm text-[#E8E8D8]/80">
                  {retirement.jerseyRetirements.length > 0 ? (
                    <span>🏆 #{retirement.player.jerseyNumber} retired</span>
                  ) : (
                    <span>(no jersey)</span>
                  )}
                </div>
              </div>
            </div>
          ))}

          {retirements.length === 0 && (
            <div className="text-center py-8 text-[#E8E8D8]/60">
              No retirements this season
            </div>
          )}
        </div>
      </div>

      <div className="bg-[#5A8352] border-[5px] border-[#C4A853] p-4">
        <div className="text-sm text-[#E8E8D8]">
          <span className="font-bold">EMPTY ROSTER SLOTS CREATED: {totalRetirements}</span>
        </div>
        <div className="text-xs text-[#E8E8D8]/60 mt-1">
          These will be filled during the Draft phase.
        </div>
      </div>

      <button
        onClick={onClose}
        className="w-full bg-[#5A8352] border-[5px] border-[#4A6844] py-4 text-lg text-[#E8E8D8] hover:bg-[#4F7D4B] active:scale-95 transition-transform shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)]"
      >
        CONTINUE TO FREE AGENCY
      </button>
    </div>
  );
}