import { useState } from "react";
import { Trophy, TrendingUp, TrendingDown, Building2, Award, Zap } from "lucide-react";

type MuseumTab = "league-history" | "team" | "stadiums" | "hall-of-fame" | "records" | "moments";
type TeamSubTab = "season-standings" | "top-10" | "accolades" | "retired-jerseys";

export interface RetiredJersey {
  number: number;
  name: string;
  years: string;
  position: string;
  teamId: string;
  retiredYear: number;
}

interface MuseumContentProps {
  retiredJerseys?: RetiredJersey[];
}

export function MuseumContent({ retiredJerseys: propRetiredJerseys = [] }: MuseumContentProps) {
  const [activeTab, setActiveTab] = useState<MuseumTab>("league-history");
  const [selectedTeam, setSelectedTeam] = useState<string>("");
  const [activeTeamSubTab, setActiveTeamSubTab] = useState<TeamSubTab>("season-standings");
  const [leagueHistoryView, setLeagueHistoryView] = useState<"champions" | "team-records" | "awards" | "leaders">("champions");
  const [sortColumn, setSortColumn] = useState<string>("war");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [stadiumSortColumn, setStadiumSortColumn] = useState<string>("name");
  const [stadiumSortDirection, setStadiumSortDirection] = useState<"asc" | "desc">("asc");
  const [recordCategory, setRecordCategory] = useState<"batting" | "pitching" | "fielding" | "team">("batting");

  // Mock teams
  const teams = ["Tigers", "Sox", "Bears", "Crocs", "Moonstars", "Nemesis", "Herbisaurs", "Wild Pigs", "Beewolves", "Moose"];

  // Mock champions data
  const champions = [
    { year: 2025, champion: "Tigers", runnerUp: "Sox", series: "4-2" },
    { year: 2024, champion: "Moonstars", runnerUp: "Beewolves", series: "4-3" },
    { year: 2023, champion: "Sox", runnerUp: "Tigers", series: "4-1" },
    { year: 2022, champion: "Crocs", runnerUp: "Nemesis", series: "4-3" },
    { year: 2021, champion: "Tigers", runnerUp: "Herbisaurs", series: "4-2" },
  ];

  // Mock team all-time records
  const teamRecords = [
    { team: "Tigers", wins: 487, losses: 361, winPct: 0.574, championships: 2, playoffApps: 4 },
    { team: "Sox", wins: 468, losses: 380, winPct: 0.552, championships: 1, playoffApps: 5 },
    { team: "Moonstars", wins: 445, losses: 403, winPct: 0.525, championships: 1, playoffApps: 3 },
    { team: "Beewolves", wins: 432, losses: 416, winPct: 0.509, championships: 0, playoffApps: 3 },
    { team: "Crocs", wins: 428, losses: 420, winPct: 0.505, championships: 1, playoffApps: 2 },
    { team: "Nemesis", wins: 412, losses: 436, winPct: 0.486, championships: 0, playoffApps: 2 },
    { team: "Wild Pigs", wins: 398, losses: 450, winPct: 0.469, championships: 0, playoffApps: 1 },
    { team: "Herbisaurs", wins: 389, losses: 459, winPct: 0.459, championships: 0, playoffApps: 2 },
    { team: "Moose", wins: 376, losses: 472, winPct: 0.443, championships: 0, playoffApps: 1 },
    { team: "Bears", wins: 361, losses: 487, winPct: 0.426, championships: 0, playoffApps: 0 },
  ];

  // Mock award winners
  const awardWinners = [
    { year: 2025, mvp: "J. Rodriguez (Tigers)", cy: "A. Brown (Sox)", roy: "M. Chen (Bears)" },
    { year: 2024, mvp: "K. Thompson (Moonstars)", cy: "D. Martinez (Crocs)", roy: "L. Johnson (Tigers)" },
    { year: 2023, mvp: "S. Wilson (Sox)", cy: "J. Rodriguez (Tigers)", roy: "P. Garcia (Nemesis)" },
    { year: 2022, mvp: "R. Williams (Crocs)", cy: "T. Davis (Moonstars)", roy: "C. Taylor (Beewolves)" },
  ];

  // Mock all-time leaders
  const allTimeLeaders = [
    { name: "J. Rodriguez", team: "Tigers", war: 64.2, pwar: 64.2, bwar: 0.0, rwar: 0.0, fwar: 0.0, era: 2.45, wins: 187 },
    { name: "S. Wilson", team: "Sox", war: 58.9, pwar: 0.0, bwar: 52.3, rwar: 4.8, fwar: 1.8, avg: 0.312, hr: 342 },
    { name: "K. Thompson", team: "Moonstars", war: 56.7, pwar: 0.0, bwar: 48.9, rwar: 2.1, fwar: 5.7, avg: 0.298, hr: 298 },
    { name: "A. Brown", team: "Sox", war: 54.3, pwar: 54.3, bwar: 0.0, rwar: 0.0, fwar: 0.0, era: 2.89, wins: 164 },
    { name: "R. Williams", team: "Crocs", war: 52.1, pwar: 0.0, bwar: 45.6, rwar: 4.9, fwar: 1.6, avg: 0.289, hr: 187 },
    { name: "M. Chen", team: "Bears", war: 49.8, pwar: 0.0, bwar: 51.2, rwar: 0.8, fwar: -2.2, avg: 0.305, hr: 389 },
    { name: "D. Martinez", team: "Crocs", war: 48.4, pwar: 48.4, bwar: 0.0, rwar: 0.0, fwar: 0.0, era: 3.12, wins: 152 },
    { name: "L. Johnson", team: "Tigers", war: 46.9, pwar: 0.0, bwar: 41.2, rwar: 3.4, fwar: 2.3, avg: 0.276, hr: 245 },
    { name: "T. Davis", team: "Moonstars", war: 45.2, pwar: 45.2, bwar: 0.0, rwar: 0.0, fwar: 0.0, era: 3.34, wins: 143 },
    { name: "P. Garcia", team: "Nemesis", war: 43.7, pwar: 0.0, bwar: 38.9, rwar: 3.1, fwar: 1.7, avg: 0.281, hr: 276 },
  ];

  // Mock season standings for selected team
  const seasonStandings = [
    { year: 2025, record: "56-34", standing: "1st AL West", playoffs: "Champions" },
    { year: 2024, record: "52-38", standing: "2nd AL West", playoffs: "Wild Card" },
    { year: 2023, record: "48-42", standing: "3rd AL West", playoffs: "Missed" },
    { year: 2022, record: "51-39", standing: "2nd AL West", playoffs: "Division Series" },
    { year: 2021, record: "58-32", standing: "1st AL West", playoffs: "Champions" },
  ];

  // Mock team top 10 players
  const teamTop10 = [
    { name: "J. Rodriguez", war: 64.2, pwar: 64.2, bwar: 0.0, rwar: 0.0, fwar: 0.0, years: "2018-2025" },
    { name: "L. Johnson", war: 46.9, pwar: 0.0, bwar: 41.2, rwar: 3.4, fwar: 2.3, years: "2019-2025" },
    { name: "Historical Player 1", war: 42.3, pwar: 0.0, bwar: 38.1, rwar: 2.8, fwar: 1.4, years: "2010-2018" },
    { name: "Historical Player 2", war: 39.8, pwar: 39.8, bwar: 0.0, rwar: 0.0, fwar: 0.0, years: "2012-2020" },
    { name: "Historical Player 3", war: 36.5, pwar: 0.0, bwar: 32.4, rwar: 2.9, fwar: 1.2, years: "2015-2022" },
    { name: "Historical Player 4", war: 34.2, pwar: 34.2, bwar: 0.0, rwar: 0.0, fwar: 0.0, years: "2011-2019" },
    { name: "Historical Player 5", war: 31.8, pwar: 0.0, bwar: 28.7, rwar: 2.1, fwar: 1.0, years: "2013-2021" },
    { name: "Historical Player 6", war: 29.4, pwar: 0.0, bwar: 26.3, rwar: 2.0, fwar: 1.1, years: "2016-2023" },
    { name: "Historical Player 7", war: 27.9, pwar: 27.9, bwar: 0.0, rwar: 0.0, fwar: 0.0, years: "2014-2022" },
    { name: "Historical Player 8", war: 25.6, pwar: 0.0, bwar: 23.1, rwar: 1.8, fwar: 0.7, years: "2017-2024" },
  ];

  // Mock team accolades
  const teamAccolades = {
    championships: [2025, 2021, 2015],
    mvps: [
      { player: "J. Rodriguez", year: 2025 },
      { player: "L. Johnson", year: 2024 },
    ],
    cyYoungs: [
      { player: "J. Rodriguez", year: 2023 },
      { player: "Historical Pitcher 1", year: 2018 },
    ],
    roys: [
      { player: "Historical Player 3", year: 2015 },
    ],
  };

  // Mock retired jerseys
  const retiredJerseys: RetiredJersey[] = [
    { number: 42, name: "J. Rodriguez", years: "2018-2025", position: "SP", teamId: "Tigers", retiredYear: 2025 },
    { number: 7, name: "Historical Legend", years: "2005-2017", position: "CF", teamId: "Tigers", retiredYear: 2017 },
    { number: 24, name: "Franchise Icon", years: "1998-2012", position: "1B", teamId: "Bears", retiredYear: 2012 },
  ];

  // Mock stadium data
  const stadiumsData = [
    { name: "Tiger Stadium", opened: 1912, capacity: 42000, overall: 102, hr: 106, doubles: 104, triples: 98 },
    { name: "Sox Field", opened: 1995, capacity: 38500, overall: 98, hr: 95, doubles: 99, triples: 102 },
    { name: "Bear Den", opened: 2001, capacity: 45000, overall: 105, hr: 108, doubles: 107, triples: 96 },
    { name: "Croc Pit", opened: 1988, capacity: 36000, overall: 97, hr: 94, doubles: 98, triples: 100 },
    { name: "Moon Base", opened: 2010, capacity: 41000, overall: 101, hr: 103, doubles: 100, triples: 99 },
    { name: "Nemesis Arena", opened: 2005, capacity: 39000, overall: 99, hr: 97, doubles: 101, triples: 101 },
    { name: "Herbi Park", opened: 1976, capacity: 35000, overall: 96, hr: 92, doubles: 97, triples: 104 },
    { name: "Pig Pen", opened: 2015, capacity: 40000, overall: 103, hr: 105, doubles: 103, triples: 97 },
    { name: "Hive Stadium", opened: 1999, capacity: 37500, overall: 100, hr: 99, doubles: 102, triples: 99 },
    { name: "Moose Lodge", opened: 2008, capacity: 43000, overall: 104, hr: 107, doubles: 105, triples: 95 },
  ];

  // Mock Hall of Fame members
  const hallOfFame = [
    { number: 42, name: "J. Rodriguez", team: "Tigers", position: "SP", inducted: 2026 },
    { number: 7, name: "Historical Legend", team: "Tigers", position: "CF", inducted: 2020 },
    { number: 99, name: "Power Slugger", team: "Sox", position: "1B", inducted: 2019 },
    { number: 24, name: "Franchise Icon", team: "Bears", position: "SS", inducted: 2015 },
    { number: 15, name: "Ace Pitcher", team: "Moonstars", position: "SP", inducted: 2018 },
    { number: 8, name: "Speed Demon", team: "Crocs", position: "CF", inducted: 2017 },
  ];

  // Mock records
  const recordsData = {
    batting: [
      { record: "Most Career Home Runs", player: "M. Chen", team: "Bears", year: "2015-2025", value: "389" },
      { record: "Highest Career Batting Average", player: "S. Wilson", team: "Sox", year: "2016-2025", value: ".312" },
      { record: "Most Career RBIs", player: "M. Chen", team: "Bears", year: "2015-2025", value: "1,247" },
      { record: "Most Home Runs (Season)", player: "M. Chen", team: "Bears", year: "2023", value: "58" },
      { record: "Highest Batting Average (Season)", player: "S. Wilson", team: "Sox", year: "2024", value: ".387" },
    ],
    pitching: [
      { record: "Most Career Wins", player: "J. Rodriguez", team: "Tigers", year: "2018-2025", value: "187" },
      { record: "Lowest Career ERA", player: "J. Rodriguez", team: "Tigers", year: "2018-2025", value: "2.45" },
      { record: "Most Career Strikeouts", player: "J. Rodriguez", team: "Tigers", year: "2018-2025", value: "2,156" },
      { record: "Most Wins (Season)", player: "J. Rodriguez", team: "Tigers", year: "2025", value: "24" },
      { record: "Lowest ERA (Season)", player: "A. Brown", team: "Sox", year: "2023", value: "1.89" },
    ],
    fielding: [
      { record: "Highest Career Fielding %", player: "R. Williams", team: "Crocs", year: "2017-2025", value: ".989" },
      { record: "Most Career Gold Gloves", player: "R. Williams", team: "Crocs", year: "2017-2025", value: "7" },
      { record: "Most Assists (Season)", player: "R. Williams", team: "Crocs", year: "2022", value: "542" },
    ],
    team: [
      { record: "Most Wins (Season)", player: "Tigers", team: "Tigers", year: "2021", value: "112" },
      { record: "Best Team ERA (Season)", player: "Sox", team: "Sox", year: "2023", value: "2.87" },
      { record: "Most Home Runs (Season)", player: "Bears", team: "Bears", year: "2023", value: "287" },
      { record: "Longest Winning Streak", player: "Tigers", team: "Tigers", year: "2025", value: "18 games" },
    ],
  };

  // Mock moments
  const moments = [
    { date: "Oct 15, 2025", title: "Rodriguez Perfect Game in World Series Game 7", reporter: "Sarah Jenkins", text: "In the most pressure-packed moment imaginable, J. Rodriguez delivered a perfect game to clinch the championship. The stadium erupted as the final out was recorded." },
    { date: "Jul 4, 2024", title: "Chen's 4 Home Runs on Independence Day", reporter: "Mike Patterson", text: "M. Chen put on a fireworks show of his own, becoming only the third player in league history to hit four home runs in a single game." },
    { date: "May 23, 2023", title: "Wilson's Walk-Off Grand Slam Completes Comeback", reporter: "Elena Rodriguez", text: "Down 6-0 in the 9th inning, the Sox mounted an impossible comeback capped by S. Wilson's walk-off grand slam that brought the crowd to its feet." },
    { date: "Sep 28, 2022", title: "Crocs Clinch Division on Final Day", reporter: "Tom Anderson", text: "In a season-ending showdown, the Crocs defeated their rivals in extra innings to secure the division title on the final day of the regular season." },
    { date: "Apr 1, 2021", title: "Johnson's Debut: 5-for-5 with 3 HRs", reporter: "Lisa Chen", text: "In one of the most memorable debuts in league history, rookie L. Johnson went 5-for-5 with three home runs in his first major league game." },
  ];

  // Sorting functions
  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortDirection("desc");
    }
  };

  const handleStadiumSort = (column: string) => {
    if (stadiumSortColumn === column) {
      setStadiumSortDirection(stadiumSortDirection === "asc" ? "desc" : "asc");
    } else {
      setStadiumSortColumn(column);
      setStadiumSortDirection("asc");
    }
  };

  const getSortedLeaders = () => {
    const sorted = [...allTimeLeaders].sort((a, b) => {
      let aVal: any = a[sortColumn as keyof typeof a];
      let bVal: any = b[sortColumn as keyof typeof b];

      if (aVal < bVal) return sortDirection === "asc" ? -1 : 1;
      if (aVal > bVal) return sortDirection === "asc" ? 1 : -1;
      return 0;
    });
    return sorted;
  };

  const getSortedStadiums = () => {
    const sorted = [...stadiumsData].sort((a, b) => {
      let aVal: any = a[stadiumSortColumn as keyof typeof a];
      let bVal: any = b[stadiumSortColumn as keyof typeof b];

      if (aVal < bVal) return stadiumSortDirection === "asc" ? -1 : 1;
      if (aVal > bVal) return stadiumSortDirection === "asc" ? 1 : -1;
      return 0;
    });
    return sorted;
  };

  return (
    <div className="space-y-4">
      {/* Main Museum Tabs */}
      <div className="bg-[#6B9462] border-[5px] border-[#4A6844] overflow-x-auto">
        <div className="flex">
          {[
            { id: "league-history", label: "LEAGUE HISTORY" },
            { id: "team", label: "TEAM" },
            { id: "stadiums", label: "STADIUMS" },
            { id: "hall-of-fame", label: "HALL OF FAME" },
            { id: "records", label: "RECORDS" },
            { id: "moments", label: "MOMENTS" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as MuseumTab)}
              className={`flex-1 px-3 py-2 text-[9px] whitespace-nowrap transition border-r-2 border-[#4A6844] last:border-r-0 ${
                activeTab === tab.id
                  ? "bg-[#4A6844] text-[#E8E8D8]"
                  : "text-[#E8E8D8]/60 hover:bg-[#5A8352]"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* League History Tab */}
      {activeTab === "league-history" && (
        <div className="space-y-4">
          {/* View Selection */}
          <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-3">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <button
                onClick={() => setLeagueHistoryView("champions")}
                className={`py-2 px-3 text-[9px] transition ${
                  leagueHistoryView === "champions"
                    ? "bg-[#4A6844] text-[#E8E8D8]"
                    : "bg-[#5A8352] text-[#E8E8D8]/60 hover:bg-[#4F7D4B]"
                }`}
              >
                CHAMPIONS
              </button>
              <button
                onClick={() => setLeagueHistoryView("team-records")}
                className={`py-2 px-3 text-[9px] transition ${
                  leagueHistoryView === "team-records"
                    ? "bg-[#4A6844] text-[#E8E8D8]"
                    : "bg-[#5A8352] text-[#E8E8D8]/60 hover:bg-[#4F7D4B]"
                }`}
              >
                TEAM RECORDS
              </button>
              <button
                onClick={() => setLeagueHistoryView("awards")}
                className={`py-2 px-3 text-[9px] transition ${
                  leagueHistoryView === "awards"
                    ? "bg-[#4A6844] text-[#E8E8D8]"
                    : "bg-[#5A8352] text-[#E8E8D8]/60 hover:bg-[#4F7D4B]"
                }`}
              >
                AWARDS
              </button>
              <button
                onClick={() => setLeagueHistoryView("leaders")}
                className={`py-2 px-3 text-[9px] transition ${
                  leagueHistoryView === "leaders"
                    ? "bg-[#4A6844] text-[#E8E8D8]"
                    : "bg-[#5A8352] text-[#E8E8D8]/60 hover:bg-[#4F7D4B]"
                }`}
              >
                ALL-TIME LEADERS
              </button>
            </div>
          </div>

          {/* Champions View */}
          {leagueHistoryView === "champions" && (
            <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
              <div
                className="text-[12px] text-[#E8E8D8] mb-3 pb-2 border-b-2 border-[#4A6844]"
                style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
              >
                CHAMPIONSHIP HISTORY
              </div>
              <div className="space-y-2">
                {champions.map((champ, idx) => (
                  <div key={idx} className="bg-[#5A8352] p-3 flex items-center gap-4">
                    <Trophy className="w-6 h-6 text-[#FFD700]" />
                    <div className="flex-1">
                      <div className="text-[11px] text-[#E8E8D8] font-bold">{champ.year}</div>
                      <div className="text-[9px] text-[#E8E8D8]/80 mt-1">
                        {champ.champion} defeated {champ.runnerUp}, {champ.series}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Team Records View */}
          {leagueHistoryView === "team-records" && (
            <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
              <div
                className="text-[12px] text-[#E8E8D8] mb-3 pb-2 border-b-2 border-[#4A6844]"
                style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
              >
                ALL-TIME TEAM RECORDS
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-[9px]">
                  <thead>
                    <tr className="border-b-2 border-[#4A6844]">
                      <th className="text-left py-2 px-2 text-[#E8E8D8]/70">TEAM</th>
                      <th className="text-center py-2 px-2 text-[#E8E8D8]/70">WINS</th>
                      <th className="text-center py-2 px-2 text-[#E8E8D8]/70">LOSSES</th>
                      <th className="text-center py-2 px-2 text-[#E8E8D8]/70">WIN %</th>
                      <th className="text-center py-2 px-2 text-[#E8E8D8]/70">TITLES</th>
                      <th className="text-center py-2 px-2 text-[#E8E8D8]/70">PLAYOFF APPS</th>
                    </tr>
                  </thead>
                  <tbody>
                    {teamRecords.map((team, idx) => (
                      <tr key={idx} className={`border-b border-[#4A6844]/30 ${idx % 2 === 0 ? "bg-[#5A8352]/20" : ""}`}>
                        <td className="py-2 px-2 text-[#E8E8D8] font-bold">{team.team}</td>
                        <td className="py-2 px-2 text-[#E8E8D8] text-center">{team.wins}</td>
                        <td className="py-2 px-2 text-[#E8E8D8] text-center">{team.losses}</td>
                        <td className="py-2 px-2 text-[#E8E8D8] text-center">{team.winPct.toFixed(3)}</td>
                        <td className="py-2 px-2 text-center">
                          <span className={team.championships > 0 ? "text-[#FFD700] font-bold" : "text-[#E8E8D8]"}>
                            {team.championships}
                          </span>
                        </td>
                        <td className="py-2 px-2 text-[#E8E8D8] text-center">{team.playoffApps}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Awards View */}
          {leagueHistoryView === "awards" && (
            <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
              <div
                className="text-[12px] text-[#E8E8D8] mb-3 pb-2 border-b-2 border-[#4A6844]"
                style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
              >
                MAJOR AWARD WINNERS
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-[9px]">
                  <thead>
                    <tr className="border-b-2 border-[#4A6844]">
                      <th className="text-left py-2 px-2 text-[#E8E8D8]/70">YEAR</th>
                      <th className="text-left py-2 px-2 text-[#E8E8D8]/70">MVP</th>
                      <th className="text-left py-2 px-2 text-[#E8E8D8]/70">CY YOUNG</th>
                      <th className="text-left py-2 px-2 text-[#E8E8D8]/70">ROOKIE OF YEAR</th>
                    </tr>
                  </thead>
                  <tbody>
                    {awardWinners.map((year, idx) => (
                      <tr key={idx} className={`border-b border-[#4A6844]/30 ${idx % 2 === 0 ? "bg-[#5A8352]/20" : ""}`}>
                        <td className="py-2 px-2 text-[#E8E8D8] font-bold">{year.year}</td>
                        <td className="py-2 px-2 text-[#E8E8D8]">{year.mvp}</td>
                        <td className="py-2 px-2 text-[#E8E8D8]">{year.cy}</td>
                        <td className="py-2 px-2 text-[#E8E8D8]">{year.roy}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* All-Time Leaders View */}
          {leagueHistoryView === "leaders" && (
            <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
              <div
                className="text-[12px] text-[#E8E8D8] mb-3 pb-2 border-b-2 border-[#4A6844]"
                style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
              >
                ALL-TIME STATISTICAL LEADERS
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-[9px]">
                  <thead>
                    <tr className="border-b-2 border-[#4A6844]">
                      <th className="text-left py-2 px-2 text-[#E8E8D8]/70">NAME</th>
                      <th className="text-left py-2 px-2 text-[#E8E8D8]/70">TEAM</th>
                      <th className="text-center py-2 px-2 text-[#E8E8D8]/70 cursor-pointer hover:text-[#E8E8D8]" onClick={() => handleSort("war")}>
                        WAR {sortColumn === "war" && (sortDirection === "asc" ? "↑" : "↓")}
                      </th>
                      <th className="text-center py-2 px-2 text-[#E8E8D8]/70 cursor-pointer hover:text-[#E8E8D8]" onClick={() => handleSort("pwar")}>
                        pWAR {sortColumn === "pwar" && (sortDirection === "asc" ? "↑" : "↓")}
                      </th>
                      <th className="text-center py-2 px-2 text-[#E8E8D8]/70 cursor-pointer hover:text-[#E8E8D8]" onClick={() => handleSort("bwar")}>
                        bWAR {sortColumn === "bwar" && (sortDirection === "asc" ? "↑" : "↓")}
                      </th>
                      <th className="text-center py-2 px-2 text-[#E8E8D8]/70 cursor-pointer hover:text-[#E8E8D8]" onClick={() => handleSort("rwar")}>
                        rWAR {sortColumn === "rwar" && (sortDirection === "asc" ? "↑" : "↓")}
                      </th>
                      <th className="text-center py-2 px-2 text-[#E8E8D8]/70 cursor-pointer hover:text-[#E8E8D8]" onClick={() => handleSort("fwar")}>
                        fWAR {sortColumn === "fwar" && (sortDirection === "asc" ? "↑" : "↓")}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {getSortedLeaders().map((player, idx) => (
                      <tr key={idx} className={`border-b border-[#4A6844]/30 ${idx % 2 === 0 ? "bg-[#5A8352]/20" : ""}`}>
                        <td className="py-2 px-2 text-[#E8E8D8]">{player.name}</td>
                        <td className="py-2 px-2 text-[#E8E8D8]">{player.team}</td>
                        <td className="py-2 px-2 text-[#E8E8D8] text-center font-bold">{player.war.toFixed(1)}</td>
                        <td className="py-2 px-2 text-[#E8E8D8] text-center">{player.pwar.toFixed(1)}</td>
                        <td className="py-2 px-2 text-[#E8E8D8] text-center">{player.bwar.toFixed(1)}</td>
                        <td className="py-2 px-2 text-[#E8E8D8] text-center">{player.rwar.toFixed(1)}</td>
                        <td className="py-2 px-2 text-[#E8E8D8] text-center">{player.fwar.toFixed(1)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Team Tab */}
      {activeTab === "team" && (
        <div className="space-y-4">
          {/* Team Selection */}
          <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
            <div className="text-[10px] text-[#E8E8D8]/70 mb-2">SELECT TEAM</div>
            <select
              value={selectedTeam}
              onChange={(e) => setSelectedTeam(e.target.value)}
              className="w-full bg-[#4A6844] text-[#E8E8D8] p-2 text-[10px] border-2 border-[#3F5A3A]"
            >
              <option value="">-- Choose a team --</option>
              {teams.map((team) => (
                <option key={team} value={team}>
                  {team}
                </option>
              ))}
            </select>
          </div>

          {/* Team Sub-Tabs (only show if team selected) */}
          {selectedTeam && (
            <>
              <div className="bg-[#6B9462] border-[5px] border-[#4A6844]">
                <div className="grid grid-cols-2 md:grid-cols-4">
                  {[
                    { id: "season-standings", label: "SEASON STANDINGS" },
                    { id: "top-10", label: "TOP 10" },
                    { id: "accolades", label: "ACCOLADES" },
                    { id: "retired-jerseys", label: "RETIRED JERSEYS" },
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTeamSubTab(tab.id as TeamSubTab)}
                      className={`px-3 py-2 text-[9px] whitespace-nowrap transition border-r-2 border-[#4A6844] last:border-r-0 ${
                        activeTeamSubTab === tab.id
                          ? "bg-[#4A6844] text-[#E8E8D8]"
                          : "text-[#E8E8D8]/60 hover:bg-[#5A8352]"
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Season Standings Sub-Tab */}
              {activeTeamSubTab === "season-standings" && (
                <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
                  <div
                    className="text-[12px] text-[#E8E8D8] mb-3 pb-2 border-b-2 border-[#4A6844]"
                    style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
                  >
                    {selectedTeam.toUpperCase()} SEASON BY SEASON
                  </div>
                  <div className="space-y-2">
                    {seasonStandings.map((season, idx) => (
                      <div key={idx} className="bg-[#5A8352] p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-[11px] text-[#E8E8D8] font-bold">{season.year}</div>
                            <div className="text-[9px] text-[#E8E8D8]/80 mt-1">
                              {season.record} • {season.standing}
                            </div>
                          </div>
                          <div className={`text-[9px] font-bold ${
                            season.playoffs.includes("Champions") ? "text-[#FFD700]" :
                            season.playoffs.includes("Series") ? "text-[#0066FF]" :
                            season.playoffs.includes("Wild") ? "text-[#5599FF]" :
                            "text-[#E8E8D8]/60"
                          }`}>
                            {season.playoffs}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Top 10 Sub-Tab */}
              {activeTeamSubTab === "top-10" && (
                <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
                  <div
                    className="text-[12px] text-[#E8E8D8] mb-3 pb-2 border-b-2 border-[#4A6844]"
                    style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
                  >
                    {selectedTeam.toUpperCase()} ALL-TIME TOP 10
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-[9px]">
                      <thead>
                        <tr className="border-b-2 border-[#4A6844]">
                          <th className="text-left py-2 px-2 text-[#E8E8D8]/70">NAME</th>
                          <th className="text-center py-2 px-2 text-[#E8E8D8]/70">YEARS</th>
                          <th className="text-center py-2 px-2 text-[#E8E8D8]/70">WAR</th>
                          <th className="text-center py-2 px-2 text-[#E8E8D8]/70">pWAR</th>
                          <th className="text-center py-2 px-2 text-[#E8E8D8]/70">bWAR</th>
                          <th className="text-center py-2 px-2 text-[#E8E8D8]/70">rWAR</th>
                          <th className="text-center py-2 px-2 text-[#E8E8D8]/70">fWAR</th>
                        </tr>
                      </thead>
                      <tbody>
                        {teamTop10.map((player, idx) => (
                          <tr key={idx} className={`border-b border-[#4A6844]/30 ${idx % 2 === 0 ? "bg-[#5A8352]/20" : ""}`}>
                            <td className="py-2 px-2 text-[#E8E8D8]">{player.name}</td>
                            <td className="py-2 px-2 text-[#E8E8D8]/70 text-center text-[8px]">{player.years}</td>
                            <td className="py-2 px-2 text-[#E8E8D8] text-center font-bold">{player.war.toFixed(1)}</td>
                            <td className="py-2 px-2 text-[#E8E8D8] text-center">{player.pwar.toFixed(1)}</td>
                            <td className="py-2 px-2 text-[#E8E8D8] text-center">{player.bwar.toFixed(1)}</td>
                            <td className="py-2 px-2 text-[#E8E8D8] text-center">{player.rwar.toFixed(1)}</td>
                            <td className="py-2 px-2 text-[#E8E8D8] text-center">{player.fwar.toFixed(1)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Accolades Sub-Tab */}
              {activeTeamSubTab === "accolades" && (
                <div className="space-y-4">
                  <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
                    <div
                      className="text-[12px] text-[#E8E8D8] mb-3 pb-2 border-b-2 border-[#4A6844]"
                      style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
                    >
                      CHAMPIONSHIPS
                    </div>
                    <div className="flex gap-3 flex-wrap">
                      {teamAccolades.championships.map((year, idx) => (
                        <div key={idx} className="bg-[#5A8352] p-4 text-center min-w-[80px]">
                          <Trophy className="w-8 h-8 text-[#FFD700] mx-auto mb-2" />
                          <div className="text-[14px] text-[#E8E8D8] font-bold">{year}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
                    <div
                      className="text-[12px] text-[#E8E8D8] mb-3 pb-2 border-b-2 border-[#4A6844]"
                      style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
                    >
                      MVP AWARDS
                    </div>
                    <div className="space-y-2">
                      {teamAccolades.mvps.map((award, idx) => (
                        <div key={idx} className="bg-[#5A8352] p-3 flex items-center gap-3">
                          <Award className="w-5 h-5 text-[#FFD700]" />
                          <div className="text-[10px] text-[#E8E8D8]">
                            <span className="font-bold">{award.player}</span> • {award.year}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
                    <div
                      className="text-[12px] text-[#E8E8D8] mb-3 pb-2 border-b-2 border-[#4A6844]"
                      style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
                    >
                      CY YOUNG AWARDS
                    </div>
                    <div className="space-y-2">
                      {teamAccolades.cyYoungs.map((award, idx) => (
                        <div key={idx} className="bg-[#5A8352] p-3 flex items-center gap-3">
                          <Award className="w-5 h-5 text-[#0066FF]" />
                          <div className="text-[10px] text-[#E8E8D8]">
                            <span className="font-bold">{award.player}</span> • {award.year}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
                    <div
                      className="text-[12px] text-[#E8E8D8] mb-3 pb-2 border-[#4A6844]"
                      style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
                    >
                      ROOKIE OF THE YEAR
                    </div>
                    <div className="space-y-2">
                      {teamAccolades.roys.map((award, idx) => (
                        <div key={idx} className="bg-[#5A8352] p-3 flex items-center gap-3">
                          <Award className="w-5 h-5 text-[#5599FF]" />
                          <div className="text-[10px] text-[#E8E8D8]">
                            <span className="font-bold">{award.player}</span> • {award.year}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Retired Jerseys Sub-Tab */}
              {activeTeamSubTab === "retired-jerseys" && (
                <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
                  <div
                    className="text-[12px] text-[#E8E8D8] mb-4 pb-2 border-b-2 border-[#4A6844]"
                    style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
                  >
                    RETIRED JERSEYS
                  </div>
                  {[...retiredJerseys, ...propRetiredJerseys].filter(jersey => jersey.teamId.toLowerCase() === selectedTeam.toLowerCase()).length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {[...retiredJerseys, ...propRetiredJerseys].filter(jersey => jersey.teamId.toLowerCase() === selectedTeam.toLowerCase()).map((jersey, idx) => (
                        <div key={idx} className="bg-[#5A8352] p-6 text-center border-[3px] border-[#4A6844]">
                          <div className="text-[48px] text-[#E8E8D8] font-bold mb-2" style={{ textShadow: "3px 3px 6px rgba(0,0,0,0.8)" }}>
                            {jersey.number}
                          </div>
                          <div className="text-[11px] text-[#E8E8D8] font-bold">{jersey.name}</div>
                          <div className="text-[8px] text-[#E8E8D8]/70 mt-1">{jersey.position} • {jersey.years}</div>
                          <div className="text-[8px] text-[#FFD700] mt-2">Retired {jersey.retiredYear}</div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-[#E8E8D8]/60 text-[10px]">
                      No retired jerseys for this team
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          {!selectedTeam && (
            <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-12 text-center">
              <div className="text-[10px] text-[#E8E8D8]/60">Select a team above to view historical data</div>
            </div>
          )}
        </div>
      )}

      {/* Stadiums Tab */}
      {activeTab === "stadiums" && (
        <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
          <div
            className="text-[12px] text-[#E8E8D8] mb-3 pb-2 border-b-2 border-[#4A6844]"
            style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
          >
            STADIUM COMPARISON
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[9px]">
              <thead>
                <tr className="border-b-2 border-[#4A6844]">
                  <th className="text-left py-2 px-2 text-[#E8E8D8]/70 cursor-pointer hover:text-[#E8E8D8]" onClick={() => handleStadiumSort("name")}>
                    STADIUM {stadiumSortColumn === "name" && (stadiumSortDirection === "asc" ? "↑" : "↓")}
                  </th>
                  <th className="text-center py-2 px-2 text-[#E8E8D8]/70 cursor-pointer hover:text-[#E8E8D8]" onClick={() => handleStadiumSort("opened")}>
                    OPENED {stadiumSortColumn === "opened" && (stadiumSortDirection === "asc" ? "↑" : "↓")}
                  </th>
                  <th className="text-center py-2 px-2 text-[#E8E8D8]/70 cursor-pointer hover:text-[#E8E8D8]" onClick={() => handleStadiumSort("capacity")}>
                    CAPACITY {stadiumSortColumn === "capacity" && (stadiumSortDirection === "asc" ? "↑" : "↓")}
                  </th>
                  <th className="text-center py-2 px-2 text-[#E8E8D8]/70 cursor-pointer hover:text-[#E8E8D8]" onClick={() => handleStadiumSort("overall")}>
                    OVERALL {stadiumSortColumn === "overall" && (stadiumSortDirection === "asc" ? "↑" : "↓")}
                  </th>
                  <th className="text-center py-2 px-2 text-[#E8E8D8]/70 cursor-pointer hover:text-[#E8E8D8]" onClick={() => handleStadiumSort("hr")}>
                    HR {stadiumSortColumn === "hr" && (stadiumSortDirection === "asc" ? "↑" : "↓")}
                  </th>
                  <th className="text-center py-2 px-2 text-[#E8E8D8]/70 cursor-pointer hover:text-[#E8E8D8]" onClick={() => handleStadiumSort("doubles")}>
                    2B {stadiumSortColumn === "doubles" && (stadiumSortDirection === "asc" ? "↑" : "↓")}
                  </th>
                  <th className="text-center py-2 px-2 text-[#E8E8D8]/70 cursor-pointer hover:text-[#E8E8D8]" onClick={() => handleStadiumSort("triples")}>
                    3B {stadiumSortColumn === "triples" && (stadiumSortDirection === "asc" ? "↑" : "↓")}
                  </th>
                </tr>
              </thead>
              <tbody>
                {getSortedStadiums().map((stadium, idx) => (
                  <tr key={idx} className={`border-b border-[#4A6844]/30 ${idx % 2 === 0 ? "bg-[#5A8352]/20" : ""}`}>
                    <td className="py-2 px-2 text-[#E8E8D8] font-bold">{stadium.name}</td>
                    <td className="py-2 px-2 text-[#E8E8D8] text-center">{stadium.opened}</td>
                    <td className="py-2 px-2 text-[#E8E8D8] text-center">{stadium.capacity.toLocaleString()}</td>
                    <td className="py-2 px-2 text-[#E8E8D8] text-center">{stadium.overall}</td>
                    <td className="py-2 px-2 text-[#E8E8D8] text-center">{stadium.hr}</td>
                    <td className="py-2 px-2 text-[#E8E8D8] text-center">{stadium.doubles}</td>
                    <td className="py-2 px-2 text-[#E8E8D8] text-center">{stadium.triples}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Hall of Fame Tab */}
      {activeTab === "hall-of-fame" && (
        <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
          <div
            className="text-[12px] text-[#E8E8D8] mb-4 pb-2 border-b-2 border-[#4A6844]"
            style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
          >
            HALL OF FAME
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {hallOfFame.map((member, idx) => (
              <div key={idx} className="bg-[#5A8352] p-6 text-center border-[3px] border-[#FFD700]">
                <Trophy className="w-8 h-8 text-[#FFD700] mx-auto mb-3" />
                <div className="text-[36px] text-[#E8E8D8] font-bold mb-2" style={{ textShadow: "3px 3px 6px rgba(0,0,0,0.8)" }}>
                  {member.number}
                </div>
                <div className="text-[11px] text-[#E8E8D8] font-bold">{member.name}</div>
                <div className="text-[8px] text-[#E8E8D8]/70 mt-1">{member.team} • {member.position}</div>
                <div className="text-[8px] text-[#FFD700] mt-2">Inducted {member.inducted}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Records Tab */}
      {activeTab === "records" && (
        <div className="space-y-4">
          {/* Record Category Selection */}
          <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-3">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <button
                onClick={() => setRecordCategory("batting")}
                className={`py-2 px-3 text-[9px] transition ${
                  recordCategory === "batting"
                    ? "bg-[#4A6844] text-[#E8E8D8]"
                    : "bg-[#5A8352] text-[#E8E8D8]/60 hover:bg-[#4F7D4B]"
                }`}
              >
                BATTING
              </button>
              <button
                onClick={() => setRecordCategory("pitching")}
                className={`py-2 px-3 text-[9px] transition ${
                  recordCategory === "pitching"
                    ? "bg-[#4A6844] text-[#E8E8D8]"
                    : "bg-[#5A8352] text-[#E8E8D8]/60 hover:bg-[#4F7D4B]"
                }`}
              >
                PITCHING
              </button>
              <button
                onClick={() => setRecordCategory("fielding")}
                className={`py-2 px-3 text-[9px] transition ${
                  recordCategory === "fielding"
                    ? "bg-[#4A6844] text-[#E8E8D8]"
                    : "bg-[#5A8352] text-[#E8E8D8]/60 hover:bg-[#4F7D4B]"
                }`}
              >
                FIELDING
              </button>
              <button
                onClick={() => setRecordCategory("team")}
                className={`py-2 px-3 text-[9px] transition ${
                  recordCategory === "team"
                    ? "bg-[#4A6844] text-[#E8E8D8]"
                    : "bg-[#5A8352] text-[#E8E8D8]/60 hover:bg-[#4F7D4B]"
                }`}
              >
                TEAM
              </button>
            </div>
          </div>

          {/* Records List */}
          <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
            <div
              className="text-[12px] text-[#E8E8D8] mb-3 pb-2 border-b-2 border-[#4A6844]"
              style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
            >
              {recordCategory.toUpperCase()} RECORDS
            </div>
            <div className="space-y-2">
              {recordsData[recordCategory].map((record, idx) => (
                <div key={idx} className="bg-[#5A8352] p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="text-[10px] text-[#E8E8D8] font-bold mb-1">{record.record}</div>
                      <div className="text-[8px] text-[#E8E8D8]/70">
                        {record.player} • {record.team} • {record.year}
                      </div>
                    </div>
                    <div className="text-[14px] text-[#FFD700] font-bold">{record.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Moments Tab */}
      {activeTab === "moments" && (
        <div className="bg-[#6B9462] border-[5px] border-[#4A6844] p-4">
          <div
            className="text-[12px] text-[#E8E8D8] mb-4 pb-2 border-b-2 border-[#4A6844]"
            style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
          >
            LEGENDARY MOMENTS
          </div>
          <div className="space-y-4">
            {moments.map((moment, idx) => (
              <div key={idx} className="bg-[#5A8352] p-4 border-l-4 border-[#FFD700]">
                <div className="flex items-start gap-3">
                  <Zap className="w-6 h-6 text-[#FFD700] flex-shrink-0 mt-1" />
                  <div className="flex-1">
                    <div className="text-[8px] text-[#E8E8D8]/70 mb-1">{moment.date}</div>
                    <div className="text-[11px] text-[#E8E8D8] font-bold mb-2">{moment.title}</div>
                    <div className="text-[9px] text-[#E8E8D8] italic mb-2">"{moment.text}"</div>
                    <div className="text-[8px] text-[#E8E8D8]/70">— {moment.reporter}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}