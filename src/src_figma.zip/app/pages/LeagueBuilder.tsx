import { useNavigate } from "react-router";
import { Database, Users, User, Folder, Shuffle, Settings, ArrowLeft } from "lucide-react";

export function LeagueBuilder() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#2d3d2f] text-[#E8E8D8] p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate("/")}
            className="p-3 bg-[#4A6844] hover:bg-[#5A8352] border-4 border-[#E8E8D8] transition active:scale-95 shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)]"
          >
            <ArrowLeft className="w-6 h-6 text-[#E8E8D8]" />
          </button>
          <div className="bg-[#5A8352] border-[6px] border-[#E8E8D8] px-8 py-3 shadow-[6px_6px_0px_0px_rgba(0,0,0,0.8)]">
            <h1 className="text-2xl font-bold text-[#E8E8D8] tracking-wider" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.8)' }}>LEAGUE BUILDER</h1>
          </div>
        </div>

        {/* Module Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          <ModuleCard
            icon={<Database className="w-8 h-8" />}
            title="LEAGUES"
            description="Create, edit, and organize league templates"
            count="3 leagues"
            color="#CC44CC"
          />

          <ModuleCard
            icon={<Users className="w-8 h-8" />}
            title="TEAMS"
            description="Manage team roster pool and branding"
            count="20 teams"
            color="#5599FF"
          />

          <ModuleCard
            icon={<User className="w-8 h-8" />}
            title="PLAYERS"
            description="Player database, ratings, and traits"
            count="506 players"
            color="#3366FF"
          />

          <ModuleCard
            icon={<Folder className="w-8 h-8" />}
            title="ROSTERS"
            description="Assign players to teams and set lineups"
            count="20 rosters"
            color="#0066FF"
          />

          <ModuleCard
            icon={<Shuffle className="w-8 h-8" />}
            title="DRAFT"
            description="Fantasy snake draft configuration"
            count="Configure"
            color="#7733DD"
          />

          <ModuleCard
            icon={<Settings className="w-8 h-8" />}
            title="RULES"
            description="Game, season, and simulation settings"
            count="4 presets"
            color="#DD0000"
          />
        </div>

        {/* Current Leagues Section */}
        <div className="bg-[#556B55] border-[6px] border-[#4A6844] p-6 shadow-[8px_8px_0px_0px_rgba(0,0,0,0.8)]">
          <div className="flex items-center justify-between mb-4">
            <div className="text-base text-[#E8E8D8] font-bold tracking-wide" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.8)' }}>▼ CURRENT LEAGUES</div>
          </div>
          
          <div className="space-y-3 mb-6">
            <LeagueRow 
              icon="⚾" 
              name="KRUSE BASEBALL LEAGUE" 
              teams={16} 
            />
            <LeagueRow 
              icon="⚾" 
              name="SUMMER LEAGUE" 
              teams={8} 
            />
            <LeagueRow 
              icon="⚾" 
              name="CHAMPIONSHIP SERIES" 
              teams={4} 
            />
          </div>

          <button className="w-full bg-[#5A8352] hover:bg-[#4A6844] border-[5px] border-[#E8E8D8] py-4 transition-all active:scale-[0.98] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,0.9)]">
            <span className="text-[#E8E8D8] font-bold text-base tracking-wide" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.8)' }}>+ CREATE NEW LEAGUE</span>
          </button>
        </div>
      </div>
    </div>
  );
}

interface ModuleCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  count: string;
  color: string;
}

function ModuleCard({ icon, title, description, count, color }: ModuleCardProps) {
  return (
    <button
      className="flex flex-col items-center text-center border-[4px] border-[#4A6844] p-6 hover:border-[#5A8352] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,0.9)] transition-all active:scale-[0.98] bg-[#556B55] group min-h-[200px] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)]"
    >
      <div className="mb-4 group-hover:scale-110 transition-transform" style={{ color }}>
        {icon}
      </div>
      <div className="text-lg font-bold text-[#E8E8D8] mb-2 tracking-wide" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.8)' }}>{title}</div>
      <div className="text-xs text-[#E8E8D8]/80 leading-relaxed mb-4 flex-grow">{description}</div>
      <div className="text-xs font-bold px-3 py-1 border-2 border-[#E8E8D8]/40 rounded-full" style={{ color, textShadow: '1px 1px 2px rgba(0,0,0,0.8)' }}>
        {count}
      </div>
    </button>
  );
}

function LeagueRow({ icon, name, teams }: { icon: string; name: string; teams: number }) {
  return (
    <button className="w-full flex items-center justify-between bg-[#4A6844] border-4 border-[#E8E8D8]/30 p-4 hover:bg-[#5A8352] hover:border-[#E8E8D8]/50 transition-all active:scale-[0.99] group shadow-[2px_2px_0px_0px_rgba(0,0,0,0.6)]">
      <div className="flex items-center gap-3">
        <span className="text-2xl">{icon}</span>
        <div className="text-left">
          <div className="text-sm font-bold text-[#E8E8D8] tracking-wide" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.8)' }}>{name}</div>
          <div className="text-xs text-[#E8E8D8]/70">{teams} teams</div>
        </div>
      </div>
      <div className="text-[#E8E8D8] text-xl group-hover:translate-x-1 transition-transform">▶</div>
    </button>
  );
}