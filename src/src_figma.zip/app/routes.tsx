import { createBrowserRouter } from "react-router";
import { AppHome } from "@/app/pages/AppHome";
import { LeagueBuilder } from "@/app/pages/LeagueBuilder";
import { FranchiseHome } from "@/app/pages/FranchiseHome";
import { FranchiseSetup } from "@/app/pages/FranchiseSetup";
import { GameTracker } from "@/app/pages/GameTracker";
import { PostGameSummary } from "@/app/pages/PostGameSummary";
import { ExhibitionGame } from "@/app/pages/ExhibitionGame";
import { WorldSeries } from "@/app/pages/WorldSeries";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: AppHome,
  },
  {
    path: "/league-builder",
    Component: LeagueBuilder,
  },
  {
    path: "/franchise/setup",
    Component: FranchiseSetup,
  },
  {
    path: "/franchise/:franchiseId",
    Component: FranchiseHome,
  },
  {
    path: "/game-tracker/:gameId",
    Component: GameTracker,
  },
  {
    path: "/post-game/:gameId",
    Component: PostGameSummary,
  },
  {
    path: "/exhibition",
    Component: ExhibitionGame,
  },
  {
    path: "/world-series",
    Component: WorldSeries,
  },
]);