---
name: spec-ui-alignment
description: Audit KBL Tracker for misalignment between spec documents, backend logic (engines/storage/hooks), and frontend UI (components/views). Use when asked to "align code with specs", "audit spec compliance", "find spec violations", "sync frontend and backend", "check if UI matches the code", or any request to ensure the implementation matches the documented requirements. Detects where the UI displays something the backend doesn't support, where the backend calculates something the UI doesn't show, and where either diverges from spec-docs.
---

# Spec-UI Alignment Auditor

## Context

KBL Tracker was built iteratively with AI tools across many sessions. Specs were written first, then implementation happened over time. Drift occurs in three ways:

1. **UI promises what backend can't deliver** — Button/display exists but backend logic is missing or broken
2. **Backend calculates what UI doesn't show** — Engine computes a value but no component renders it
3. **Both exist but diverge from spec** — Implementation differs from documented requirements

This skill systematically finds and resolves all three types.

## Pre-Flight

1. Read these spec docs (in order):
   - `spec-docs/CURRENT_STATE.md`
   - `spec-docs/REQUIREMENTS.md`
   - `spec-docs/IMPLEMENTATION_PLAN_v2.md`
   - `spec-docs/FEATURE_WISHLIST.md` (124 known gaps)
2. Catalog the spec docs available in `spec-docs/` — each represents a system with specific requirements
3. Run `npm run build` and `npm test` for baseline

## Audit Methodology

### Layer 1: Spec → Backend Alignment

For each spec document, verify the backend implements what's documented.

**Process per spec file:**

```
For each spec in spec-docs/:
  1. Extract all requirements/rules/formulas from the spec
  2. Identify the corresponding source files (engines, storage, hooks, types)
  3. For each requirement:
     - Does corresponding code exist?
     - Does the code implement the requirement correctly?
     - Are edge cases from the spec handled?
  4. Flag: MISSING (no code), WRONG (code differs from spec), PARTIAL (incomplete)
```

**Key spec-to-code mappings:**

| Spec Doc | Backend Files | What to Verify |
|----------|--------------|----------------|
| `BWAR_CALCULATION_SPEC.md` | `src/engines/bwarCalculator.ts` | Formula matches, inputs correct, edge cases |
| `PWAR_CALCULATION_SPEC.md` | `src/engines/pwarCalculator.ts` | Same |
| `FWAR_CALCULATION_SPEC.md` | `src/engines/fwarCalculator.ts` | Same |
| `RWAR_CALCULATION_SPEC.md` | `src/engines/rwarCalculator.ts` | Same |
| `MWAR_CALCULATION_SPEC.md` | `src/engines/mwarCalculator.ts` | Same |
| `SALARY_SYSTEM_SPEC.md` | `src/engines/salaryCalculator.ts` | Salary formula, caps, floors |
| `MOJO_FITNESS_SYSTEM_SPEC.md` | `src/engines/mojoEngine.ts`, `fitnessEngine.ts` | Mojo/fitness calculations |
| `SPECIAL_EVENTS_SPEC.md` | Detection functions, event handlers | Events detected correctly |
| `SMB4_GAME_MECHANICS.md` | GameTracker components, state logic | Only SMB4 features exist, no real-baseball-only features |

### Layer 2: Backend → UI Alignment

Verify the UI correctly displays what the backend provides.

**Process:**

```
For each engine/calculator in src/engines/:
  1. Identify all exported functions and their return types
  2. Search src/components/ for imports/usage of each function
  3. For each function:
     - Is it called anywhere in UI code? If not → UNUSED_BACKEND
     - Where it IS called, does the UI display the result correctly?
     - Does the UI handle null/undefined/loading states?
     - Are the labels/formatting correct for the data type?

For each hook in src/hooks/:
  1. Identify what data the hook provides
  2. Find all components that consume the hook
  3. Verify components use all relevant fields
  4. Verify components don't reference fields that don't exist
```

### Layer 3: UI → Backend Alignment

Verify every UI element has working backend support.

**Process:**

```
For each component in src/components/:
  1. Identify all interactive elements (buttons, inputs, selects, toggles)
  2. For each element:
     - What handler fires on interaction?
     - Does the handler call real backend logic?
     - Or is it: no-op, TODO, console.log only, hardcoded response?
  3. Identify all displayed data (text, numbers, charts, lists)
  4. For each display:
     - Where does the data come from?
     - Is the source real (storage/engine) or fake (hardcoded)?
  5. Flag: DEAD_BUTTON (no handler), FAKE_DATA (hardcoded), BROKEN_PIPE (handler exists but fails)
```

### Layer 4: Cross-Layer Consistency

Check for contradictions across layers:

- Spec says feature X exists, but UI has no entry point for it
- UI has button for feature Y, but spec doesn't mention it
- Backend calculates Z one way, spec documents it another way
- Type definitions don't match between layers (TypeScript interfaces vs actual data shapes)

## Specific Checks for KBL Tracker

### GameTracker-Specific
- Every outcome button in UI has a corresponding state handler
- State handler correctly updates game state per baseball rules
- Game state changes propagate to: score display, base diagram, out count, batter info, pitcher info, play-by-play log
- Inning transitions work in both UI and state
- Game end conditions trigger correct flow

### Stats/Calculations-Specific
- WAR values displayed match WAR engine output for same inputs
- runsPerWin uses correct formula: `10 × (seasonGames / 162)` NOT Pythagorean 17.87
- Salary calculations in UI match salaryCalculator output
- Stats aggregation (game → season → career) produces correct totals

### Franchise-Specific (if implemented)
- Season/standings data comes from actual game results
- Roster management reflects actual team data
- Any narrative elements connect to real game events

## Fix Protocol

For each misalignment found, determine the correct resolution:

| Situation | Resolution |
|-----------|-----------|
| Spec is right, code is wrong | Fix code to match spec |
| Code is intentionally different from spec | Update spec, add entry to DECISIONS_LOG.md |
| UI element has no backend | Either implement backend or remove UI element |
| Backend has no UI | Either add UI or document as future work |
| Both wrong | Fix to match what's correct per baseball logic and SMB4 mechanics |

**For each fix:**
1. State what's misaligned and why
2. Propose the fix (which layer to change)
3. Implement
4. Verify: build passes, tests pass, UI renders correctly
5. Update CURRENT_STATE.md if implementation status changed

## Anti-Hallucination Rules

- Do NOT claim code matches spec without reading BOTH the spec and the code
- Do NOT assume a function works correctly because it exists — read the logic
- Do NOT fix spec-to-match-code unless the code is intentionally better (document in DECISIONS_LOG)
- If you find a contradiction you can't resolve, flag it for user decision
- Always verify TypeScript types compile after changes (`npm run build`)

## Output

Produce a structured alignment report:

```
# Spec-UI Alignment Audit Report
Date: [date]
Specs audited: [list]
Components audited: [list]
Engines audited: [list]

## Misalignments Found

### Critical (Logic/Data Errors)
| ID | Spec | Code Location | Expected | Actual | Fix |
|----|------|--------------|----------|--------|-----|

### Major (Missing Connections)  
| ID | Layer | Description | Resolution |
|----|-------|-------------|-----------|

### Minor (Cosmetic/Labels)
| ID | Location | Issue | Fix |
|----|----------|-------|-----|

### Dead Code (Backend with No UI)
| Function/Module | What It Does | Recommendation |
|----------------|-------------|----------------|

### Dead UI (Buttons/Displays with No Backend)
| Component | Element | What's Missing |
|-----------|---------|---------------|

## Summary Stats
- Spec requirements checked: [X]
- Aligned: [Y]
- Misaligned: [Z]  
- Coverage: [Y/X]%
```

Save report to `spec-docs/SPEC_UI_ALIGNMENT_REPORT.md`.
