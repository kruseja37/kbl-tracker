---
name: dummy-data-scrubber
description: Scan KBL Tracker codebase for hardcoded dummy data, placeholder values, mock objects, and static demo content, then replace with dynamic data pulls that align with specs and actual data layer. Use when asked to "find dummy data", "replace placeholder data", "connect real data", "remove hardcoded values", "scrub demo data", or any request to ensure the app displays real dynamic data instead of static placeholders. Covers GameTracker, franchise mode, stats views, and all UI components.
---

# Dummy Data Scrubber

## Context

KBL Tracker (React + TypeScript + Vite) was built iteratively with AI tools. During development, components often get hardcoded values, placeholder text, mock objects, or demo data that was never replaced with actual dynamic data pulls. This skill systematically finds and replaces all such instances.

## Pre-Flight

1. Read `spec-docs/CURRENT_STATE.md` for implementation status
2. Read `spec-docs/REQUIREMENTS.md` for expected data sources
3. Understand the data layer: `src/storage/` (IndexedDB), `src/engines/` (calculations), `src/hooks/` (React state)
4. Run `npm run build` — baseline must compile

## Detection Patterns

Scan all files in `src/` for these patterns:

### Pattern 1: Hardcoded Strings
```typescript
// SUSPECT: Literal strings that should be dynamic
"Player Name"
"John Doe"
"Team A" / "Team B"
"Sample"
"Test"
"TODO"
"placeholder"
"Lorem"
"xxx" / "TBD"
```

### Pattern 2: Hardcoded Numbers
```typescript
// SUSPECT: Magic numbers that should come from game state or calculations
const avg = 0.300    // Should be calculated from at-bats/hits
const era = 3.50     // Should be calculated from earned runs/innings
const hr = 25        // Should come from player stats
score = 4            // Should come from game state
```

### Pattern 3: Mock Objects / Arrays
```typescript
// SUSPECT: Inline data objects not from storage/state
const players = [{ name: "...", position: "SS", ... }]
const standings = [{ team: "...", wins: 50, ... }]
const lineup = ["Player 1", "Player 2", ...]
```

### Pattern 4: Commented-Out Dynamic Code with Static Fallback
```typescript
// const data = useGameState()  ← commented out
const data = { runs: 0, hits: 0 }  // ← static replacement
```

### Pattern 5: Default Props That Should Be Required
```typescript
// Component accepts optional data with hardcoded defaults
function PlayerCard({ name = "Unknown", avg = ".000" })
// Should require actual data: function PlayerCard({ name, avg }: PlayerCardProps)
```

### Pattern 6: Stale Demo State in Hooks/Context
```typescript
// Initial state that looks like demo data
const [gameState, setGameState] = useState({
  homeTeam: "Sirloins",  // Should be selected by user
  awayTeam: "Moose",     // Should be selected by user
  inning: 5,             // Should start at 1
})
```

## Scanning Process

### Step 1: Automated Grep Scan

Run these searches and collect results:

```bash
# Hardcoded player/team names
grep -rn --include="*.tsx" --include="*.ts" -E '"[A-Z][a-z]+ [A-Z][a-z]+"' src/
grep -rn --include="*.tsx" --include="*.ts" -iE '(placeholder|sample|test data|mock|dummy|todo|tbd|lorem)' src/

# Suspicious numeric literals (stats that should be calculated)
grep -rn --include="*.tsx" --include="*.ts" -E '\b(0\.\d{3}|\d+\.\d{2})\b' src/components/

# Inline array/object literals in components (not in types or test files)
grep -rn --include="*.tsx" -E '(const|let) \w+ = \[?\{' src/components/

# Default prop values
grep -rn --include="*.tsx" -E '= "[A-Z]' src/components/

# Commented-out data fetching
grep -rn --include="*.tsx" --include="*.ts" -E '//.*use[A-Z]|//.*fetch|//.*get[A-Z]' src/
```

### Step 2: Manual Component Walk

For each component directory in `src/components/`:

1. Open the main component file
2. Identify all displayed text, numbers, and data
3. Trace each piece of displayed data back to its source:
   - Comes from props? → Trace up to parent
   - Comes from hook/context? → Verify hook pulls from storage
   - Comes from local state? → Is initial value real or placeholder?
   - Hardcoded in JSX? → **FLAG IT**

### Step 3: Cross-Reference with Data Layer

For each flagged instance:

1. Identify what the data SHOULD be (from specs or baseball logic)
2. Check if the correct data source exists:
   - `src/storage/gameStorage.ts` for game data
   - `src/storage/seasonAggregator.ts` for season stats
   - `src/storage/milestoneAggregator.ts` for career stats
   - `src/engines/` for calculated values (WAR, salary, mojo, etc.)
   - `src/hooks/` for React state management
3. If data source exists → wire up the connection
4. If data source doesn't exist → document as missing, create if straightforward

## Replacement Protocol

For each dummy data instance:

### Categorize
| Category | Action |
|----------|--------|
| Data source exists, just not connected | Wire up the import/hook call |
| Data source exists but returns wrong shape | Add transformation layer |
| Data source doesn't exist yet | Create it if <30 min work, else document as TODO |
| Intentional default (empty state) | Keep but verify it's appropriate |
| Test/dev-only data | Move to test files, remove from production code |

### Replace
1. Import the correct data source (hook, storage call, engine)
2. Replace hardcoded value with dynamic value
3. Add loading state if data is async
4. Add null/empty check with appropriate fallback
5. Verify TypeScript types align

### Verify After Each Replacement
- `npm run build` passes
- Component renders correctly with real data
- Component renders correctly with empty/null data (new game, no history)
- No TypeScript errors

## Component Priority Order

Scrub in this order (GameTracker first since it's most built-out):

1. `src/components/GameTracker/` — all subcomponents
2. `src/components/` — top-level views (Dashboard, Stats, etc.)
3. `src/hooks/` — verify hooks return real data
4. `src/engines/` — verify calculations use real inputs
5. Any remaining files

## Anti-Hallucination Rules

- Do NOT replace a value unless you've confirmed the dynamic source exists and works
- Do NOT assume a hook or storage method exists — verify by reading the file
- Do NOT create elaborate new data fetching infrastructure — use what exists
- If unsure whether something is intentionally static vs accidentally hardcoded, flag it for user review rather than changing it
- After replacements, verify the app still works by running build AND visual check

## Output

Produce a structured report:

```
# Dummy Data Scrub Report
Date: [date]
Files scanned: [count]
Instances found: [count]
Instances fixed: [count]
Instances deferred: [count] (with reasons)

## Fixed
| File | Line | Was | Now | Data Source |
|------|------|-----|-----|-------------|

## Deferred (Needs User Decision)
| File | Line | Current Value | Why Deferred |
|------|------|---------------|-------------|

## Missing Data Sources (New Work Needed)
| Component Needs | Data Description | Suggested Implementation |
|----------------|-----------------|------------------------|
```

Save report to `spec-docs/DUMMY_DATA_SCRUB_REPORT.md`.
