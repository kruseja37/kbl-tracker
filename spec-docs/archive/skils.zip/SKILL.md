---
name: gametracker-logic-tester
description: Exhaustive automated testing of KBL Tracker GameTracker baseball logic and UI state integrity. Use when testing at-bat outcomes, baserunner movement, inning transitions, game state changes, scoring logic, or any GameTracker flow. Covers every possible at-bat outcome combined with every possible base/out state, verifies UI updates correctly, and catches logic errors that require baseball knowledge to identify. Trigger on "test gametracker", "test baseball logic", "test at-bat outcomes", "find logic bugs", "test game flow", or any request to verify GameTracker correctness.
---

# GameTracker Logic Tester

## Context

KBL Tracker is a React + TypeScript + Vite app tracking Super Mega Baseball 4 (SMB4) games. The GameTracker records at-bats and manages game state. This skill systematically tests every reachable game state to find logic and UI bugs.

**SMB4 is NOT real baseball.** No balks, no catcher interference, no umpire reviews. See `spec-docs/SMB4_GAME_MECHANICS.md` for what exists in SMB4.

## Pre-Flight

1. Read `spec-docs/CURRENT_STATE.md` for what's implemented
2. Read `spec-docs/SMB4_GAME_MECHANICS.md` for valid game mechanics
3. Run `npm run build` — must exit 0
4. Run `npm test` — baseline must pass
5. Start dev server: `npm run dev`
6. Open browser via Playwright MCP to `http://localhost:5173`

## State Space Definition

Every GameTracker state is defined by:

```
GameState = {
  inning: 1-9+ (top/bottom)
  outs: 0, 1, 2
  bases: 8 combinations (empty, 1st, 2nd, 3rd, 1st+2nd, 1st+3rd, 2nd+3rd, loaded)
  score: [away, home]
  count: balls (0-3), strikes (0-2)
  lineup_position: 1-9 (batting order)
}
```

## At-Bat Outcomes to Test

Every outcome that can occur in SMB4:

### Hits
- Single (runner advances vary by base state)
- Double (runner advances vary)
- Triple (all runners score)
- Home Run: Over Fence, Wall Scraper
- Infield single (if implemented)

### Outs
- Ground out (fielder position matters for force/tag)
- Fly out (deep enough for sac fly? tagging up?)
- Line out
- Strikeout (swinging, looking)
- Double play (GO + runner out — verify auto-correction)
- Triple play (rare but valid)
- Fielder's choice
- Sacrifice fly (runner on 3rd, <2 outs)
- Sacrifice bunt

### No-out outcomes
- Walk (BB)
- Hit by pitch (HBP)
- Error (fielder, position)
- Reached on error

### Special events
- Stolen base
- Caught stealing
- Wild pitch / passed ball (runner advancement)
- Intentional walk
- Defensive substitution
- Pitching change
- Pinch hitter / Pinch runner

## Testing Protocol

### Phase 1: State Transition Matrix (Automated)

Write and execute test scripts that programmatically drive the GameTracker through state combinations. For each base/out combination (8 bases × 3 outs = 24 states), apply every applicable outcome and verify:

```
For each base_state in [empty, 1st, 2nd, 3rd, 1st+2nd, 1st+3rd, 2nd+3rd, loaded]:
  For each out_count in [0, 1, 2]:
    For each outcome in [all_outcomes]:
      1. Set game to this state
      2. Apply outcome
      3. VERIFY:
         - Correct runners scored
         - Correct runners advanced
         - Correct new base state
         - Correct out count
         - Correct inning transition (if 3rd out)
         - Batter stats updated correctly
         - Pitcher stats updated correctly
         - Score updated correctly
         - Next batter loaded correctly
         - UI reflects all changes
```

### Phase 2: Critical Baseball Logic Checks

Test scenarios requiring baseball knowledge:

**Force play vs tag play:**
- Runner on 1st, ground ball → force at 2nd (runner doesn't need to be tagged)
- Runner on 2nd only, ground ball → tag play (runner can retreat)
- Bases loaded ground ball → force everywhere

**Sacrifice fly rules:**
- Runner on 3rd, 0 outs, fly out → runner scores, batter gets SF (not an AB)
- Runner on 3rd, 2 outs, fly out → inning over, runner does NOT score
- Runner on 2nd only, fly out → NOT a sac fly even if runner advances

**Double play logic:**
- Runner on 1st, ground out → should prompt/auto-detect DP possibility
- 2 outs → no DP possible (only one out needed)
- Verify GO + runner out auto-corrects to DP (per known bug fix Jan 25)

**Inning transitions:**
- 3rd out recorded → side retired, switch batting team
- Bottom of 9th, home team ahead → game over (don't play bottom)
- Extra innings: verify proper continuation

**Batting order:**
- After 9th batter, wraps to 1st
- Pinch hitter takes spot, next AB goes to next lineup position
- Substitutions maintain correct order

**Run scoring on 3rd out:**
- Runner crosses plate BEFORE 3rd out on tag play → run counts
- Runner crosses plate on force out → run does NOT count
- Verify this distinction in scoring logic

### Phase 3: UI Verification via Playwright

For each state transition tested in Phase 2, also verify via browser:

1. Navigate to GameTracker
2. Start a new game (or load test state)
3. Execute the outcome sequence
4. Screenshot after each outcome
5. Verify visually:
   - Diamond shows correct baserunners
   - Score display updated
   - Out indicators correct
   - Current batter/pitcher info correct
   - Outcome buttons available/disabled appropriately
   - No UI elements in broken/impossible state

### Phase 4: Edge Cases

- First at-bat of game (initialization)
- Last out of inning (transition)
- Last out of game (game end flow)
- Walk-off scenarios (home team wins in bottom of 9th+)
- Mercy rule (if SMB4 has one — check mechanics doc)
- Maximum runs in an inning (no limit, but test 10+ to stress UI)
- Full batting around (9+ batters in one inning)
- Pitcher batting (if applicable in SMB4 — check DH rules)

## Bug Classification

When a bug is found, classify:

| Severity | Definition | Example |
|----------|-----------|---------|
| Critical | Wrong game state, data corruption | Runner scores but score doesn't update |
| Major | Logic error visible to baseball-literate user | Sac fly counted as regular out |
| Minor | Cosmetic or non-functional | Diamond animation glitch |
| Enhancement | Works but could be smarter | Doesn't auto-detect obvious DP |

## Fix Protocol

For each bug found:

1. Document: state, outcome, expected vs actual
2. Identify root cause in source code (read the component/hook/engine)
3. Propose fix with explanation
4. Implement fix
5. Re-run the specific test case that failed
6. Re-run full Phase 1 matrix to check for regressions
7. Run `npm test` to verify existing tests still pass
8. Run `npm run build` to verify no type errors

## Anti-Hallucination Rules

- Do NOT claim a test passed without actually running it
- Do NOT assume baseball logic is correct — verify against real rules
- Do NOT skip edge cases because "they probably work"
- If a fix doesn't resolve the bug on first try, STOP. Re-diagnose from scratch
- After 2 failed fix attempts on same bug, reassess whether you're fixing the right thing
- Always check `spec-docs/SMB4_GAME_MECHANICS.md` before assuming a feature exists

## Output

After testing, produce a structured report:

```
# GameTracker Logic Test Report
Date: [date]
States tested: [X] / [total]
Bugs found: [count by severity]

## Critical Bugs
[list with reproduction steps]

## Major Bugs  
[list with reproduction steps]

## Minor Bugs
[list]

## All Tests Passed
[list of state/outcome combos that passed]
```

Save report to `spec-docs/GAMETRACKER_TEST_REPORT.md`.
